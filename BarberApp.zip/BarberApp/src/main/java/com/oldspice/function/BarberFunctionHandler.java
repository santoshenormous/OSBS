package com.oldspice.function;

import java.util.List;
import java.util.Optional;

import org.bson.Document;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.oldspice.model.Barber;
import com.oldspice.service.BarberService;

public class BarberFunctionHandler {

	@FunctionName("createBarber")
	public HttpResponseMessage createBarber(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.ANONYMOUS) HttpRequestMessage<Optional<Barber>> request,
			final ExecutionContext context) throws Exception {

		context.getLogger().info("createProductCategoryr HTTP trigger processed a request.");
		try {

			Barber barber = request.getBody().get();

			new BarberService().createBarber(barber);

			return request.createResponseBuilder(HttpStatus.OK).body("Barber Created Successfully").build();
		} catch (Exception e) {
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}
	}
	
	 @FunctionName("findBarberById")
	    public HttpResponseMessage findBarberById(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.GET},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Barber>> request,
				final ExecutionContext context) throws Exception {
			context.getLogger().info("findBarberById HTTP trigger processed a request.");
			
			String barberId = request.getQueryParameters().get("id");
			
			Document document = new BarberService().findBarberById(barberId);
			if (document == null) {
				return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
			} else {
				return request.createResponseBuilder(HttpStatus.OK).body(document.toJson()).build();
			}
		}
	 
	 @FunctionName("findAllBarbers")
	    public HttpResponseMessage findAllBarbers(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.GET},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Barber>> request,
				final ExecutionContext context) throws Exception {

			context.getLogger().info("findAllBarbers HTTP trigger processed a request.");
			List<Document> docs = new BarberService().findAllBarbers();
			if (docs.isEmpty()) {
				return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
			} else {
				return request.createResponseBuilder(HttpStatus.OK).body(docs).build();
			}

		}
	  @FunctionName("updateBarber")
	    public HttpResponseMessage updateBarber(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.PUT},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Barber>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("updateBarber HTTP trigger processed a request.");
	     
	        Barber barber = request.getBody().get();
	       Document document =  new BarberService().updateBarber(barber);
	       if(document!=null)
	        {
	        	
	        	return request.createResponseBuilder(HttpStatus.OK).body("Barber Updated Successfully").build();
	        }
	        else
	        {
	        	return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	       
	      }
	 
	  @FunctionName("deleteBarber")
	    public HttpResponseMessage deleteBarber(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.DELETE},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Barber>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("deleteUser HTTP trigger processed a request.");
	        
	        String barberId = request.getQueryParameters().get("id");
	       
	        long count= new BarberService().deleteBarber(barberId);
	      
	        if(count==0)
	        {
	        	return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	        else
	        {
	        	
	        	return request.createResponseBuilder(HttpStatus.OK).body("Barber Deleted Successfully").build();
	        }
			
	    }
	 


}
