package com.oldspice.function;

import java.util.List;
import java.util.Optional;

import org.bson.Document;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.oldspice.model.BarberSchedule;
import com.oldspice.service.BarberScheduleService;

public class BarberScheduleFunctionHandler {

	@FunctionName("createBarberSchedule")
	public HttpResponseMessage createBarber(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.ANONYMOUS) HttpRequestMessage<Optional<BarberSchedule>> request,
			final ExecutionContext context) throws Exception {

		context.getLogger().info("createBarberSchedule HTTP trigger processed a request.");
		try {

			BarberSchedule barber = request.getBody().get();

			new BarberScheduleService().createBarberSchedule(barber);

			return request.createResponseBuilder(HttpStatus.OK).body("Barber Schedule Created Successfully").build();
		} catch (Exception e) {
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}
	}
	
	 @FunctionName("findBarberScheduleById")
	    public HttpResponseMessage findBarberById(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.GET},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<BarberSchedule>> request,
				final ExecutionContext context) throws Exception {
			context.getLogger().info("findBarberScheduleById HTTP trigger processed a request.");
			
			String barberId = request.getQueryParameters().get("id");
			
			Document document = new BarberScheduleService().findBarberScheduleById(barberId);
			if (document == null) {
				return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
			} else {
				return request.createResponseBuilder(HttpStatus.OK).body(document.toJson()).build();
			}
		}
	 
	 @FunctionName("findAllBarberSchedules")
	    public HttpResponseMessage findAllBarbers(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.GET},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<BarberSchedule>> request,
				final ExecutionContext context) throws Exception {

			context.getLogger().info("findAllBarberSchedules HTTP trigger processed a request.");
			List<Document> docs = new BarberScheduleService().findAllBarberSchedules();
			if (docs.isEmpty()) {
				return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
			} else {
				return request.createResponseBuilder(HttpStatus.OK).body(docs).build();
			}

		}
	  @FunctionName("updateBarberSchedule")
	    public HttpResponseMessage updateBarber(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.PUT},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<BarberSchedule>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("updateBarberSchedule HTTP trigger processed a request.");
	     
	        BarberSchedule barber = request.getBody().get();
	       Document document =  new BarberScheduleService().updateBarberSchedule(barber);
	       if(document!=null)
	        {
	        	
	        	return request.createResponseBuilder(HttpStatus.OK).body("Barber Schedule Updated Successfully").build();
	        }
	        else
	        {
	        	return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	       
	      }
	 
	  @FunctionName("deleteBarberSchedule")
	    public HttpResponseMessage deleteBarberSchedule(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.DELETE},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<BarberSchedule>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("deleteBarberSchedule HTTP trigger processed a request.");
	        
	        String barberId = request.getQueryParameters().get("id");
	       
	        long count= new BarberScheduleService().deleteBarberSchedule(barberId);
	      
	        if(count==0)
	        {
	        	return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	        else
	        {
	        	
	        	return request.createResponseBuilder(HttpStatus.OK).body("Barber Schedule Deleted Successfully").build();
	        }
			
	    }
	 


}
