package com.oldspice.service;

import java.util.List;

import com.oldspice.model.Barber;
import com.oldspice.repository.BarberRepository;

import org.bson.Document;

public class BarberService {
	
	public void createBarber(Barber barber)
	 {     
		new BarberRepository().createBarber(barber);
	 }
	
	
	 public Document findBarberById(String barberId) {
		return new BarberRepository().findBarberById(barberId);
	 }
	 
	 public List<Document> findAllBarbers()
    {
		 return new BarberRepository().findAllBarbers();
    }
	 
	 
	 public Long deleteBarber(String barberId)
	    {
		 return new BarberRepository().deleteBarber(barberId);
	    }
	 
	 
	  public Document updateBarber(Barber barber) {
		  return new BarberRepository().updateBarber(barber);
	  }
	 

}
