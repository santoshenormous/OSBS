package com.oldspice.service;

import java.util.List;

import com.oldspice.model.BarberSchedule;
import com.oldspice.repository.BarberScheduleRepository;

import org.bson.Document;

public class BarberScheduleService {
	
	public void createBarberSchedule(BarberSchedule barber)
	 {     
		new BarberScheduleRepository().createBarberSchedule(barber);
	 }
	
	
	 public Document findBarberScheduleById(String barberId) {
		return new BarberScheduleRepository().findBarberScheduleById(barberId);
	 }
	 
	 public List<Document> findAllBarberSchedules()
    {
		 return new BarberScheduleRepository().findAllBarberSchedules();
    }
	 
	 
	 public Long deleteBarberSchedule(String barberId)
	    {
		 return new BarberScheduleRepository().deleteBarberSchedule(barberId);
	    }
	 
	 
	  public Document updateBarberSchedule(BarberSchedule barber) {
		  return new BarberScheduleRepository().updateBarberSchedule(barber);
	  }
	 

}
