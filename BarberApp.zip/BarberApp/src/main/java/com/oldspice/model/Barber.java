package com.oldspice.model;

import java.io.Serializable;

public class Barber implements Serializable
{
private static final long serialVersionUID = 1L;


private String id;
private String userId;
private String firstName;
private String lastName;
private String phone;
private String email;
private Object summary;
private Object social;
private Object media;
private Object address;

public Barber()
{
	
}


public Barber(String id, String userId, String firstName, String lastName, String phone, String email, Object summary,
		Object social, Object media, Object address) {
	super();
	this.id = id;
	this.userId = userId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.phone = phone;
	this.email = email;
	this.summary = summary;
	this.social = social;
	this.media = media;
	this.address = address;
}


public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Object getSummary() {
	return summary;
}
public void setSummary(Object summary) {
	this.summary = summary;
}
public Object getSocial() {
	return social;
}
public void setSocial(Object social) {
	this.social = social;
}
public Object getMedia() {
	return media;
}
public void setMedia(Object media) {
	this.media = media;
}
public Object getAddress() {
	return address;
}
public void setAddress(Object address) {
	this.address = address;
}


@Override
public String toString() {
	return "Barber [id=" + id + ", userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", phone=" + phone + ", email=" + email + ", summary=" + summary + ", social=" + social + ", media="
			+ media + ", address=" + address + "]";
}



}
