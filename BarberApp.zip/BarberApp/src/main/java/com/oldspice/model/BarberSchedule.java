package com.oldspice.model;

import java.io.Serializable;

public class BarberSchedule implements Serializable
{
private static final long serialVersionUID = 1L;


private String id;
private String barberId;
private String barberAvailabitly;
public BarberSchedule()
{
	
}
public BarberSchedule(String id, String barberId, String barberAvailabitly) {
	super();
	this.id = id;
	this.barberId = barberId;
	this.barberAvailabitly = barberAvailabitly;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getBarberId() {
	return barberId;
}
public void setBarberId(String barberId) {
	this.barberId = barberId;
}
public String getBarberAvailabitly() {
	return barberAvailabitly;
}
public void setBarberAvailabitly(String barberAvailabitly) {
	this.barberAvailabitly = barberAvailabitly;
}
@Override
public String toString() {
	return "BarberSchedule [id=" + id + ", barberId=" + barberId + ", barberAvailabitly=" + barberAvailabitly + "]";
}




}
