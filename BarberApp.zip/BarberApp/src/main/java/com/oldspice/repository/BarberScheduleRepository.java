package com.oldspice.repository;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.oldspice.model.BarberSchedule;
import com.oldspice.util.MongoUtil;

public class BarberScheduleRepository {
	
	MongoCollection<Document> barberScheduleCollection= MongoUtil.getCollectionName("BarberSchedule");
	
	
	 public void createBarberSchedule(BarberSchedule barberSchedule)
		{
			Document barberDocument = new Document("_id", barberSchedule.getId());
			barberDocument.append("barberId", barberSchedule.getBarberId());
			barberDocument.append("barberAvailabitly", barberSchedule.getBarberAvailabitly());

			
			barberScheduleCollection.insertOne(barberDocument);
		}
	 
	 
		public Document findBarberScheduleById(String barberId) {

			Document document = barberScheduleCollection.find(new BasicDBObject("_id", barberId)).first();		

			return document;
		}
	 
	 @SuppressWarnings({ "rawtypes", "unchecked" })
		public List<Document> findAllBarberSchedules() {

			FindIterable it = barberScheduleCollection.find();
			List docs = new ArrayList<Document>();
			it.into(docs);
			return docs;

		}
	 public Document updateBarberSchedule( BarberSchedule barberSchedule) {
         
		 Document document = barberScheduleCollection.find(new BasicDBObject("_id", barberSchedule.getId())).first();
	        if(document!=null)
	        {
	        	barberScheduleCollection.deleteOne(eq("_id", barberSchedule.getId()));
	        	Document barberDocument = new Document("_id", barberSchedule.getId());
				barberDocument.append("barberId", barberSchedule.getBarberId());
				barberDocument.append("barberAvailabitly", barberSchedule.getBarberAvailabitly());
				barberScheduleCollection.insertOne(barberDocument);

	        }
	        return document;
	    }
	 
	 
	 
	 
	 public Long deleteBarberSchedule(String barberId)
	    {
	            
		  long count= barberScheduleCollection.deleteOne(eq("_id",barberId)).getDeletedCount();
	      
	       return count;
			
	    }
	    
	 
}
