package com.oldspice.repository;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.oldspice.model.Barber;
import com.oldspice.util.MongoUtil;

public class BarberRepository {
	
	MongoCollection<Document> barberCollection= MongoUtil.getCollectionName("Barber");
	
	
	 public void createBarber(Barber barber)
		{
			Document barberDocument = new Document("_id", barber.getId());
			barberDocument.append("userId", barber.getUserId());
			barberDocument.append("firstName", barber.getFirstName());
			barberDocument.append("lastName", barber.getLastName());
			barberDocument.append("phone", barber.getPhone());
			barberDocument.append("email", barber.getEmail());
			barberDocument.append("summary", barber.getSummary());
			barberDocument.append("social", barber.getSocial());
			barberDocument.append("media", barber.getMedia());
			barberDocument.append("address", barber.getAddress());

			
			barberCollection.insertOne(barberDocument);
		}
	 
	 
		public Document findBarberById(String barberId) {

			Document document = barberCollection.find(new BasicDBObject("_id", barberId)).first();		

			return document;
		}
	 
	 @SuppressWarnings({ "rawtypes", "unchecked" })
		public List<Document> findAllBarbers() {

			FindIterable it = barberCollection.find();
			List docs = new ArrayList<Document>();
			it.into(docs);
			return docs;

		}
	 public Document updateBarber( Barber barber) {
         
		 Document document = barberCollection.find(new BasicDBObject("_id", barber.getId())).first();
	        if(document!=null)
	        {
	        	barberCollection.deleteOne(eq("_id", barber.getId()));
	        	Document barberDocument = new Document("_id", barber.getId());
				barberDocument.append("userId", barber.getUserId());
				barberDocument.append("firstName", barber.getFirstName());
				barberDocument.append("lastName", barber.getLastName());
				barberDocument.append("phone", barber.getPhone());
				barberDocument.append("email", barber.getEmail());
				barberDocument.append("summary", barber.getSummary());
				barberDocument.append("social", barber.getSocial());
				barberDocument.append("media", barber.getMedia());
				barberDocument.append("address", barber.getAddress());
	        	barberCollection.insertOne(barberDocument);

	        }
	        return document;
	    }
	 
	 
	 
	 
	 public Long deleteBarber(String barberId)
	    {
	            
		  long count= barberCollection.deleteOne(eq("_id",barberId)).getDeletedCount();
	      
	       return count;
			
	    }
	    
	 
}
