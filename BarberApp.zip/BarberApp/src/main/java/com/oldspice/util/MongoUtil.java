package com.oldspice.util;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoUtil {
	

	
  private static MongoDatabase database = null;
    
  private static  MongoClient mongoClient = null;


    static MongoClient getConnection() {
    	try
    	{
        if (mongoClient == null) {
        	MongoClientURI uri = new MongoClientURI("mongodb://osbs-dev-docdb:sl9k1sVQW2MneV0rTPu9c47t1DBoQdp3yiPRjQjoupG6BE6oXTZHoNTzcl7xXB5ltIgjFAtUbsbB0gBaW14y0A==@osbs-dev-docdb.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@osbs-dev-docdb@");
        	 mongoClient = new MongoClient(uri);     
        		
        	    
        }
    	}
    	catch(Exception e)
    	{
    		
    	}
        return mongoClient;
    }
    
    
  public static MongoDatabase getDataBase()  {
	  mongoClient=  getConnection();
        if (mongoClient!= null) {
        	// Get database
    	     database = mongoClient.getDatabase("testdb");
    	  
        }

        return database;
    }
  
  public static MongoCollection<Document> getCollectionName(String name)
  {
	  MongoCollection<Document>  collectionName =MongoUtil.getDataBase().getCollection(name);
	  return collectionName;
  }
    
    public static void closeConnection(MongoClient conn) {

        try {

        
        	conn.close();
        	

        } catch (Exception e) {

        }

    }

}
