package com.oldspice.service;

import java.util.List;

import org.bson.Document;
import com.oldspice.model.Appointment;
import com.oldspice.repository.AppointmentRepository;

public class AppointmentService {


	public void createAppointment(Appointment appointment)
	 {     
		new AppointmentRepository().createAppointment(appointment);
	 }
	
	
	 public Document findAppointment(String userId,String barberId) {
		return new AppointmentRepository().findAppointment(userId, barberId);
	 }
	 
	 public List<Document> findAllAppointments()
     {
		 return new AppointmentRepository().findAllAppointments();
     }
	 
	 
	 public Long deleteAppointment(String userId,String barberId)
	    {
		 return new AppointmentRepository().deleteAppointment(userId, barberId);
	    }
	 
	 
	  public Document updateAppointment(Appointment appointment) {
		  return new AppointmentRepository().updateAppointment(appointment);
	  }
	 
	 
}
