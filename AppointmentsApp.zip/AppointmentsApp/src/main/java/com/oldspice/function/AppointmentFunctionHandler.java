package com.oldspice.function;

import java.util.List;
import java.util.Optional;

import org.bson.Document;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.oldspice.model.Appointment;
import com.oldspice.service.AppointmentService;

public class AppointmentFunctionHandler {
	
	    @FunctionName("createAppointment")
	    public HttpResponseMessage createAppointment(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.POST},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Appointment>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("createAppointment HTTP trigger processed a request.");
	         try
	        {
	        	
	        	Appointment appointment = request.getBody().get();
	        
	           new AppointmentService().createAppointment(appointment);
	       
	     
	       
	        return request.createResponseBuilder(HttpStatus.OK).body("Appointment Created Successfully").build();
	        } catch (Exception e) {
	      return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
	    }
			
	    }
	 
	    @FunctionName("findAppointment")
	    public HttpResponseMessage findAppointment(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.GET},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Appointment>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("findAppointment HTTP trigger processed a request.");
	        
	        String userId = request.getQueryParameters().get("userId");
	        String barberId = request.getQueryParameters().get("barberId");
	       
	        Document document = new AppointmentService().findAppointment(userId, barberId);
	     
	        if(null==document)
	        {
	        	return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
	        }
	        else
	        {
	        	return request.createResponseBuilder(HttpStatus.OK).body(document.toJson()).build();
	        }
			
	    }
	 
	    @FunctionName("findAllAppointments")
	    public HttpResponseMessage findAllAppointments(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.GET},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Appointment>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("findAllAppointments HTTP trigger processed a request.");
	        
	       List<Document> documents = new AppointmentService().findAllAppointments();

        
	        if(null==documents)
	        {
	        	return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
	        }
	        else
	        {
	        	return request.createResponseBuilder(HttpStatus.OK).body(documents).build();
	        }
			
	    }
	    
	    
	    @FunctionName("deleteAppointment")
	    public HttpResponseMessage deleteAppointment(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.DELETE},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Appointment>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("deleteAppointment HTTP trigger processed a request.");
	        
	        String userId = request.getQueryParameters().get("userId");
	        String barberId = request.getQueryParameters().get("barberId");
	       
	        long count= new AppointmentService().deleteAppointment(userId, barberId);
	      
	        if(count==0)
	        {
	        	return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	        else
	        {
	        	
	        	return request.createResponseBuilder(HttpStatus.OK).body("Appointment Deleted Successfully").build();
	        }
			
	    }

	    @FunctionName("updateAppointment")
	    public HttpResponseMessage updateAppointment(
	            @HttpTrigger(
	                name = "req",
	                methods = {HttpMethod.PUT},
	                authLevel = AuthorizationLevel.ANONYMOUS)
	                HttpRequestMessage<Optional<Appointment>> request,
	            final ExecutionContext context) throws Exception {
		 
	        context.getLogger().info("updateAppointment HTTP trigger processed a request.");
	     
	        Appointment appointment = request.getBody().get();
	       Document document =  new AppointmentService().updateAppointment(appointment);
	       if(document!=null)
	        {
	        	
	        	return request.createResponseBuilder(HttpStatus.OK).body("Appointment Updated Successfully").build();
	        }
	        else
	        {
	        	return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).build();
	        }
	       
	      }

}
