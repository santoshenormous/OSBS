package com.oldspice.repository;

import java.util.ArrayList;
import java.util.List;
import org.bson.Document;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.oldspice.model.Appointment;
import com.oldspice.util.MongoUtil;

public class AppointmentRepository {
	MongoCollection<Document> appointmentCollection= MongoUtil.getCollectionName("Appointment");

	
	
	 public void createAppointment(Appointment appointment)
	 {     
		 
		
		
	        Document appointmentDocument = new Document("_id", appointment.getId());
	        appointmentDocument.append("userId", appointment.getUserId());
	        appointmentDocument.append("barberId", appointment.getBarberId());
	        appointmentDocument.append("appointmentDate", appointment.getAppointmentDate());
	        appointmentDocument.append("createdDate", appointment.getCreatedDate());
	        appointmentDocument.append("createdBy", appointment.getCreatedBy());
	        appointmentDocument.append("notes", appointment.getNotes());
	        appointmentDocument.append("serviceId", appointment.getServiceId());
	        appointmentDocument.append("location", appointment.getLocation());
	        appointmentDocument.append("address", appointment.getAddress());
	        appointmentCollection.insertOne(appointmentDocument);
		 
	 }
	 
	 public Document findAppointment(String userId,String barberId) {
         
		 Document document = appointmentCollection.find(new Document("userId",userId).append("barberId", barberId)).first();
	       
			return document;
	    }
	    
	        @SuppressWarnings({ "rawtypes", "unchecked" })
			public List<Document> findAllAppointments()
		     {
			 
		     FindIterable it = appointmentCollection.find();
	         List docs = new ArrayList<Document>();
	         it.into(docs);
	        return docs;
				
		    }

	 
	        public Long deleteAppointment(String userId,String barberId)
		    {
		            
			  long count= appointmentCollection.deleteOne(new Document("userId",userId).append("barberId", barberId)).getDeletedCount();
		      
		       return count;
				
		    }
	        
	        
	      
	        public Document updateAppointment(Appointment appointment) {
	            
	  		  Document document = appointmentCollection.find(new BasicDBObject("userId",appointment.getUserId()).append("barberId", appointment.getBarberId())).first();
	  	        if(document!=null)
	  	        {
	  	        	appointmentCollection.deleteOne(new Document("userId",appointment.getUserId()).append("barberId", appointment.getBarberId()));
	  	        	
	  	        	
	  	        	Document appointmentDocument = new Document("_id", appointment.getId());
	  		        appointmentDocument.append("userId", appointment.getUserId());
	  		        appointmentDocument.append("barberId", appointment.getBarberId());
	  		        appointmentDocument.append("appointmentDate", appointment.getAppointmentDate());
	  		        appointmentDocument.append("createdDate", appointment.getCreatedDate());
	  		        appointmentDocument.append("createdBy", appointment.getCreatedBy());
	  		        appointmentDocument.append("notes", appointment.getNotes());
	  		        appointmentDocument.append("serviceId", appointment.getServiceId());
	  		        appointmentDocument.append("location", appointment.getLocation());
	  		        appointmentDocument.append("address", appointment.getAddress());
	  		        appointmentCollection.insertOne(appointmentDocument);
	  	        }
	  	        return document;
	  	    }
}
