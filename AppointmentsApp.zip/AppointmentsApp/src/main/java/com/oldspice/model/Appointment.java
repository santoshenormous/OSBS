package com.oldspice.model;

import java.io.Serializable;

public class Appointment implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String userId;
	private String barberId;
	private String appointmentDate;
	private String createdDate;
	private String createdBy;
	private String notes;
	private String serviceId;
	private String location;
	private String address;
	
	
	public Appointment(String id, String userId, String barberId, String appointmentDate, String createdDate,
			String createdBy, String notes, String serviceId, String location, String address) {
		super();
		this.id = id;
		this.userId = userId;
		this.barberId = barberId;
		this.appointmentDate = appointmentDate;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.notes = notes;
		this.serviceId = serviceId;
		this.location = location;
		this.address = address;
	}
	public Appointment()
	{
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getBarberId() {
		return barberId;
	}
	public void setBarberId(String barberId) {
		this.barberId = barberId;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	@Override
	public String toString() {
		return "Appointment [id=" + id + ", userId=" + userId + ", barberId=" + barberId + ", appointmentDate="
				+ appointmentDate + ", createdDate=" + createdDate + ", createdBy=" + createdBy + ", notes=" + notes
				+ ", serviceId=" + serviceId + ", location=" + location + ", address=" + address + "]";
	}
	
	
	

}
