package com.oldspice.model;

public class TherapistPersonalInfo {
	
	private String first_name;
	private String last_name;
	private String name;
	private String nick_name;
	private Integer gender;
	
	public TherapistPersonalInfo()
	{
		
	}
	public TherapistPersonalInfo(String first_name, String last_name, String name, String nick_name, Integer gender) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.name = name;
		this.nick_name = nick_name;
		this.gender = gender;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNick_name() {
		return nick_name;
	}
	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return "TherapistPersonalInfo [first_name=" + first_name + ", last_name=" + last_name + ", name=" + name
				+ ", nick_name=" + nick_name + ", gender=" + gender + "]";
	}
	
	
	
	

}
