package com.oldspice.model;

import java.io.Serializable;

public class BookingResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String id;
	private BookingError Error;
	
	public BookingResp()
	{
		
	}

	public BookingResp(String id, BookingError error) {
		super();
		this.id = id;
		Error = error;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BookingError getError() {
		return Error;
	}

	public void setError(BookingError error) {
		Error = error;
	}

	@Override
	public String toString() {
		return "BookingResp [id=" + id + ", Error=" + Error + "]";
	}
	
	
	
	

}
