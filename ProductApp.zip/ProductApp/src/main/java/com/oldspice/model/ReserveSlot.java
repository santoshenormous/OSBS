package com.oldspice.model;

import java.io.Serializable;

public class ReserveSlot implements Serializable
{

private static final long serialVersionUID = 1L;


private String bookingId;
private String timeSlot;

public ReserveSlot()
{
	
}

public ReserveSlot(String bookingId, String timeSlot) {
	super();
	this.bookingId = bookingId;
	this.timeSlot = timeSlot;
}

public String getBookingId() {
	return bookingId;
}

public void setBookingId(String bookingId) {
	this.bookingId = bookingId;
}

public String getTimeSlot() {
	return timeSlot;
}

public void setTimeSlot(String timeSlot) {
	this.timeSlot = timeSlot;
}

@Override
public String toString() {
	return "ReserveSlot [bookingId=" + bookingId + ", timeSlot=" + timeSlot + "]";
}





}
