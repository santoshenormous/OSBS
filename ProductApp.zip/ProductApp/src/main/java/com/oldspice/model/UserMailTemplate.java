package com.oldspice.model;

public class UserMailTemplate {
	
	private int template_id;
	private String email;
	private MergeFields merge_fields;
	private String accepts_marketing;
	
	public UserMailTemplate()
	{
		
	}
	public UserMailTemplate(int template_id, String email, MergeFields merge_fields, String accepts_marketing) {
		super();
		this.template_id = template_id;
		this.email = email;
		this.merge_fields = merge_fields;
		this.accepts_marketing = accepts_marketing;
	}
	public int getTemplate_id() {
		return template_id;
	}
	public void setTemplate_id(int template_id) {
		this.template_id = template_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public MergeFields getMerge_fields() {
		return merge_fields;
	}
	public void setMerge_fields(MergeFields merge_fields) {
		this.merge_fields = merge_fields;
	}
	public String isAccepts_marketing() {
		return accepts_marketing;
	}
	public void setAccepts_marketing(String accepts_marketing) {
		this.accepts_marketing = accepts_marketing;
	}
	
	@Override
	public String toString() {
		return "UserMailTemplate [template_id=" + template_id + ", email=" + email + ", merge_fields=" + merge_fields
				+ ", accepts_marketing=" + accepts_marketing + "]";
	}
	
	
	

}
