package com.oldspice.model;

import java.io.Serializable;

public class RescReq implements Serializable
{

	private static final long serialVersionUID = 1L;

	private String email;
	private String serviceType;
	private String userName;
	private String serviceTime;
	private String serviceDate;
	private String barberName;
	private String accepts_marketing;
	
	public RescReq()
	{
		
	}

	public RescReq(String email, String serviceType, String userName, String serviceTime, String serviceDate,
			String barberName, String accepts_marketing) {
		super();
		this.email = email;
		this.serviceType = serviceType;
		this.userName = userName;
		this.serviceTime = serviceTime;
		this.serviceDate = serviceDate;
		this.barberName = barberName;
		this.accepts_marketing = accepts_marketing;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getServiceTime() {
		return serviceTime;
	}

	public void setServiceTime(String serviceTime) {
		this.serviceTime = serviceTime;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getBarberName() {
		return barberName;
	}

	public void setBarberName(String barberName) {
		this.barberName = barberName;
	}

	public String getAccepts_marketing() {
		return accepts_marketing;
	}

	public void setAccepts_marketing(String accepts_marketing) {
		this.accepts_marketing = accepts_marketing;
	}

	@Override
	public String toString() {
		return "RescReq [email=" + email + ", serviceType=" + serviceType + ", userName=" + userName + ", serviceTime="
				+ serviceTime + ", serviceDate=" + serviceDate + ", barberName=" + barberName + ", accepts_marketing="
				+ accepts_marketing + "]";
	}
	
	
	
	
	
	
}
