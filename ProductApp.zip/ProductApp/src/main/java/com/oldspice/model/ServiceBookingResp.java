package com.oldspice.model;

import java.io.Serializable;
import java.util.List;

public class ServiceBookingResp implements Serializable
{
    private static final long serialVersionUID = 1L;
	private String center_id;
	private String date;
	private String is_only_catalog_employees;
	private List<Guests> guests;
	
	
	public ServiceBookingResp()
	{
		
	}


	public ServiceBookingResp(String center_id, String date, String is_only_catalog_employees, List<Guests> guests) {
		super();
		this.center_id = center_id;
		this.date = date;
		this.is_only_catalog_employees = is_only_catalog_employees;
		this.guests = guests;
	}


	public String getCenter_id() {
		return center_id;
	}


	public void setCenter_id(String center_id) {
		this.center_id = center_id;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getIs_only_catalog_employees() {
		return is_only_catalog_employees;
	}


	public void setIs_only_catalog_employees(String is_only_catalog_employees) {
		this.is_only_catalog_employees = is_only_catalog_employees;
	}


	public List<Guests> getGuests() {
		return guests;
	}


	public void setGuests(List<Guests> guests) {
		this.guests = guests;
	}


	@Override
	public String toString() {
		return "ServiceBookingResp [center_id=" + center_id + ", date=" + date + ", is_only_catalog_employees="
				+ is_only_catalog_employees + ", guests=" + guests + "]";
	}


	
}
