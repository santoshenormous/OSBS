package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class ServiceResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	private Services[] services;
	
	
	public ServiceResp()
	{
		
	}


	public ServiceResp(Services[] services) {
		super();
		this.services = services;
	}


	public Services[] getServices() {
		return services;
	}


	public void setServices(Services[] services) {
		this.services = services;
	}


	@Override
	public String toString() {
		return "ServiceResp [services=" + Arrays.toString(services) + "]";
	}

	
	
	
}
