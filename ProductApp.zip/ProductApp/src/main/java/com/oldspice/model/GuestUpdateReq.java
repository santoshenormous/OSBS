package com.oldspice.model;

public class GuestUpdateReq {
	
	private String firstName;
	private String lastName;
	private String searchEmail;
	private String updateEmail;
	
	public GuestUpdateReq()
	{
		
	}

	public GuestUpdateReq(String firstName, String lastName, String searchEmail, String updateEmail) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.searchEmail = searchEmail;
		this.updateEmail = updateEmail;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSearchEmail() {
		return searchEmail;
	}

	public void setSearchEmail(String searchEmail) {
		this.searchEmail = searchEmail;
	}

	public String getUpdateEmail() {
		return updateEmail;
	}

	public void setUpdateEmail(String updateEmail) {
		this.updateEmail = updateEmail;
	}

	@Override
	public String toString() {
		return "GuestUpdateReq [firstName=" + firstName + ", lastName=" + lastName + ", searchEmail=" + searchEmail
				+ ", updateEmail=" + updateEmail + "]";
	}
	
	
	
	
	

}
