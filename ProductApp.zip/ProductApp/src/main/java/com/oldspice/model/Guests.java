package com.oldspice.model;

import java.io.Serializable;
import java.util.List;

public class Guests implements Serializable
{
private static final long serialVersionUID = 1L;

private String id;

private List<Items> items;



public Guests()
{
	
}



public Guests(String id, List<Items> items) {
	super();
	this.id = id;
	this.items = items;
}



public String getId() {
	return id;
}



public void setId(String id) {
	this.id = id;
}



public List<Items> getItems() {
	return items;
}



public void setItems(List<Items> items) {
	this.items = items;
}



}
