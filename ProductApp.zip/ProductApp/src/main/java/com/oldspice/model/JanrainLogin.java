package com.oldspice.model;

import java.io.Serializable;

public class JanrainLogin implements Serializable
{
   private static final long serialVersionUID = 1L;
	private String signInEmailAddress;
	private String currentPassword;
	
	public JanrainLogin(String signInEmailAddress, String currentPassword) {
		super();
		this.signInEmailAddress = signInEmailAddress;
		this.currentPassword = currentPassword;
	}
	
	public JanrainLogin()
	{
		
	}
	
	
	public String getSignInEmailAddress() {
		return signInEmailAddress;
	}
	public void setSignInEmailAddress(String signInEmailAddress) {
		this.signInEmailAddress = signInEmailAddress;
	}
	public String getCurrentPassword() {
		return currentPassword;
	}
	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	@Override
	public String toString() {
		return "JanrainLogin [signInEmailAddress=" + signInEmailAddress + ", currentPassword=" + currentPassword + "]";
	}
	
	
	
	
	
	
	
}
