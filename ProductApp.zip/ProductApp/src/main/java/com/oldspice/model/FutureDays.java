package com.oldspice.model;

public class FutureDays {

	private String Day;
	private boolean IsAvailable;
	
	public FutureDays()
	{
		
	}
	public FutureDays(String day, boolean isAvailable) {
		super();
		Day = day;
		IsAvailable = isAvailable;
	}
	public String getDay() {
		return Day;
	}
	public void setDay(String day) {
		Day = day;
	}
	public boolean isIsAvailable() {
		return IsAvailable;
	}
	public void setIsAvailable(boolean isAvailable) {
		IsAvailable = isAvailable;
	}
	@Override
	public String toString() {
		return "FutureDays [Day=" + Day + ", IsAvailable=" + IsAvailable + "]";
	}
	
	
	
	
}
