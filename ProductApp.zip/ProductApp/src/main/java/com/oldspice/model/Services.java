package com.oldspice.model;

public class Services 
{


private String id;
private String code;
private String name;
private String description;
private String duration;
private PriceInfo price_info;
private String additional_info;
public Services()
{
	
}
public Services(String id, String code, String name, String description, String duration, PriceInfo price_info,
		String additional_info) {
	super();
	this.id = id;
	this.code = code;
	this.name = name;
	this.description = description;
	this.duration = duration;
	this.price_info = price_info;
	this.additional_info = additional_info;
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public PriceInfo getPrice_info() {
	return price_info;
}
public void setPrice_info(PriceInfo price_info) {
	this.price_info = price_info;
}
public String getAdditional_info() {
	return additional_info;
}
public void setAdditional_info(String additional_info) {
	this.additional_info = additional_info;
}
@Override
public String toString() {
	return "Services [id=" + id + ", code=" + code + ", name=" + name + ", description=" + description + ", duration="
			+ duration + ", price_info=" + price_info + ", additional_info=" + additional_info + "]";
}



}
