package com.oldspice.model;

import java.io.Serializable;

public class SlotReserveResp implements Serializable
{

private static final long serialVersionUID = 1L;

private boolean is_reserved;
private String reservation_id;
private String expiry_time;
private int blocking_time;
private ApiError Error;
public SlotReserveResp()
{
	
}
public SlotReserveResp(boolean is_reserved, String reservation_id, String expiry_time, int blocking_time,
		ApiError error) {
	super();
	this.is_reserved = is_reserved;
	this.reservation_id = reservation_id;
	this.expiry_time = expiry_time;
	this.blocking_time = blocking_time;
	Error = error;
}
public boolean isIs_reserved() {
	return is_reserved;
}
public void setIs_reserved(boolean is_reserved) {
	this.is_reserved = is_reserved;
}
public String getReservation_id() {
	return reservation_id;
}
public void setReservation_id(String reservation_id) {
	this.reservation_id = reservation_id;
}
public String getExpiry_time() {
	return expiry_time;
}
public void setExpiry_time(String expiry_time) {
	this.expiry_time = expiry_time;
}
public int getBlocking_time() {
	return blocking_time;
}
public void setBlocking_time(int blocking_time) {
	this.blocking_time = blocking_time;
}
public ApiError getError() {
	return Error;
}
public void setError(ApiError error) {
	Error = error;
}
@Override
public String toString() {
	return "SlotReserveResp [is_reserved=" + is_reserved + ", reservation_id=" + reservation_id + ", expiry_time="
			+ expiry_time + ", blocking_time=" + blocking_time + ", Error=" + Error + "]";
}


}
