package com.oldspice.model;

import java.io.Serializable;

public class ServiceConfirmResp implements Serializable
{
	
private static final long serialVersionUID = 1L;
private boolean is_confirmed;

private ServiceInvoice invoice;


private BookingError Error;

public ServiceConfirmResp()
{
	
}

public ServiceConfirmResp(boolean is_confirmed, ServiceInvoice invoice, BookingError error) {
	super();
	this.is_confirmed = is_confirmed;
	this.invoice = invoice;
	Error = error;
}

public boolean isIs_confirmed() {
	return is_confirmed;
}

public void setIs_confirmed(boolean is_confirmed) {
	this.is_confirmed = is_confirmed;
}

public ServiceInvoice getInvoice() {
	return invoice;
}

public void setInvoice(ServiceInvoice invoice) {
	this.invoice = invoice;
}

public BookingError getError() {
	return Error;
}

public void setError(BookingError error) {
	Error = error;
}

@Override
public String toString() {
	return "ServiceConfirmResp [is_confirmed=" + is_confirmed + ", invoice=" + invoice + ", Error=" + Error + "]";
}



	
}
