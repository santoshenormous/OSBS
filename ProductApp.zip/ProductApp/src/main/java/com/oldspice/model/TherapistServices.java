package com.oldspice.model;

import java.io.Serializable;

public class TherapistServices implements Serializable
{
	
private static final long serialVersionUID = 1L;

private TherapistService Service;

public TherapistServices()
{
	
}

public TherapistServices(TherapistService service) {
	super();
	Service = service;
}

public TherapistService getService() {
	return Service;
}

public void setService(TherapistService service) {
	Service = service;
}

@Override
public String toString() {
	return "TherapistServices [Service=" + Service + "]";
}



}
