package com.oldspice.model;

public class ApiResp {

	private String message;
	
	public ApiResp()
	{
		
	}

	public ApiResp(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ApiResp [message=" + message + "]";
	}
	
	
	
	
	
}
