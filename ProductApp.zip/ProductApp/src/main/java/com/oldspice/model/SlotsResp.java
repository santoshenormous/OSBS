package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class SlotsResp implements Serializable
{

private static final long serialVersionUID = 1L;


private Slots[] slots;

private FutureDays[] future_days;
private String next_available_day;

public SlotsResp()

{
	
}

public SlotsResp(Slots[] slots, FutureDays[] future_days, String next_available_day) {
	super();
	this.slots = slots;
	this.future_days = future_days;
	this.next_available_day = next_available_day;
}

public Slots[] getSlots() {
	return slots;
}

public void setSlots(Slots[] slots) {
	this.slots = slots;
}

public FutureDays[] getFuture_days() {
	return future_days;
}

public void setFuture_days(FutureDays[] future_days) {
	this.future_days = future_days;
}

public String getNext_available_day() {
	return next_available_day;
}

public void setNext_available_day(String next_available_day) {
	this.next_available_day = next_available_day;
}

@Override
public String toString() {
	return "SlotsResp [slots=" + Arrays.toString(slots) + ", future_days=" + Arrays.toString(future_days)
			+ ", next_available_day=" + next_available_day + "]";
}

}
