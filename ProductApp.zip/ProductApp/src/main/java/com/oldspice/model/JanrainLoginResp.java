package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class JanrainLoginResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private CaptureUser capture_user;
	private String stat;
	private String access_token;
   private GuestUpdateData[] guests;
   private String error;
   private JanRainUserRegError invalid_fields;
   
   public JanrainLoginResp()
   {
	   
   }

public JanrainLoginResp(CaptureUser capture_user, String stat, String access_token, GuestUpdateData[] guests,
		String error, JanRainUserRegError invalid_fields) {
	super();
	this.capture_user = capture_user;
	this.stat = stat;
	this.access_token = access_token;
	this.guests = guests;
	this.error = error;
	this.invalid_fields = invalid_fields;
}

public CaptureUser getCapture_user() {
	return capture_user;
}

public void setCapture_user(CaptureUser capture_user) {
	this.capture_user = capture_user;
}

public String getStat() {
	return stat;
}

public void setStat(String stat) {
	this.stat = stat;
}

public String getAccess_token() {
	return access_token;
}

public void setAccess_token(String access_token) {
	this.access_token = access_token;
}

public GuestUpdateData[] getGuests() {
	return guests;
}

public void setGuests(GuestUpdateData[] guests) {
	this.guests = guests;
}

public String getError() {
	return error;
}

public void setError(String error) {
	this.error = error;
}

public JanRainUserRegError getInvalid_fields() {
	return invalid_fields;
}

public void setInvalid_fields(JanRainUserRegError invalid_fields) {
	this.invalid_fields = invalid_fields;
}

@Override
public String toString() {
	return "JanrainLoginResp [capture_user=" + capture_user + ", stat=" + stat + ", access_token=" + access_token
			+ ", guests=" + Arrays.toString(guests) + ", error=" + error + ", invalid_fields=" + invalid_fields + "]";
}


   
   

}
