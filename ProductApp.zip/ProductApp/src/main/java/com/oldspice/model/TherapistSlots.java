package com.oldspice.model;

import java.io.Serializable;

public class TherapistSlots implements Serializable
{

	private static final long serialVersionUID = 1L;

	private String Id;
	
	private String FullName;
	private String FirstName;
	private String LastName;
	
	public TherapistSlots()
	{
		
	}

	public TherapistSlots(String id, String fullName, String firstName, String lastName) {
		super();
		Id = id;
		FullName = fullName;
		FirstName = firstName;
		LastName = lastName;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	@Override
	public String toString() {
		return "TherapistSlots [Id=" + Id + ", FullName=" + FullName + ", FirstName=" + FirstName + ", LastName="
				+ LastName + "]";
	}

	
	

}
