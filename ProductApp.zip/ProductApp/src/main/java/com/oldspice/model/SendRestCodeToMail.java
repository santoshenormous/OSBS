package com.oldspice.model;

import java.io.Serializable;

public class SendRestCodeToMail  implements Serializable
{

	private static final long serialVersionUID = 1L;
	

private String signInEmailAddress;


public SendRestCodeToMail(String signInEmailAddress) {
	super();
	this.signInEmailAddress = signInEmailAddress;
}

public SendRestCodeToMail()
{
	
}

public String getSignInEmailAddress() {
	return signInEmailAddress;
}


public void setSignInEmailAddress(String signInEmailAddress) {
	this.signInEmailAddress = signInEmailAddress;
}

@Override
public String toString() {
	return "ForgotPassword [signInEmailAddress=" + signInEmailAddress + "]";
}


}
