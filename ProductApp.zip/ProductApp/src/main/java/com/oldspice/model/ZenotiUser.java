package com.oldspice.model;

import java.io.Serializable;

public class ZenotiUser implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String center_id;
	
	private PersonalInfo personal_info;
	
	public ZenotiUser()
	{
		
	}

	public ZenotiUser(String center_id, PersonalInfo personal_info) {
		super();
		this.center_id = center_id;
		this.personal_info = personal_info;
	}

	public String getCenter_id() {
		return center_id;
	}

	public void setCenter_id(String center_id) {
		this.center_id = center_id;
	}

	public PersonalInfo getPersonal_info() {
		return personal_info;
	}

	public void setPersonal_info(PersonalInfo personal_info) {
		this.personal_info = personal_info;
	}

	@Override
	public String toString() {
		return "ZenotiUser [center_id=" + center_id + ", personal_info=" + personal_info + "]";
	}
	
	

}
