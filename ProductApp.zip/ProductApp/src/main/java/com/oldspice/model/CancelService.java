package com.oldspice.model;

import java.io.Serializable;

public class CancelService implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String invoiceId;
	
	public CancelService()
	{
		
	}

	public CancelService(String invoiceId) {
		super();
		this.invoiceId = invoiceId;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	@Override
	public String toString() {
		return "cancelService [invoiceId=" + invoiceId + "]";
	}
	
	
	

}
