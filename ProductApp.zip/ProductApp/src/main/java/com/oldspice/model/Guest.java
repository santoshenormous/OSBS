package com.oldspice.model;

public class Guest
{

private String Id;

private String FirstName;

private String LastName;

	
}
