package com.oldspice.model;

import java.io.Serializable;

public class GuestDetails implements Serializable
{

private static final long serialVersionUID = 1L;

 private String id;
 private String center_id;

 
 public GuestDetails()
 {
	 
 }
 
public GuestDetails(String id, String center_id) {
	super();
	this.id = id;
	this.center_id = center_id;
	
}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getCenter_id() {
	return center_id;
}
public void setCenter_id(String center_id) {
	this.center_id = center_id;
}

@Override
public String toString() {
	return "GuestDetails [id=" + id + ", center_id=" + center_id + "]";
}

 
 

}
