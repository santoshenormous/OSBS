package com.oldspice.model;

import java.io.Serializable;

public class Rescresp implements Serializable
{

	private static final long serialVersionUID = 1L;
	private String email;
	private String template_id;
	private String message;
	
	public Rescresp()
	{
		
	}
	
	public Rescresp(String email, String template_id, String message) {
		super();
		this.email = email;
		this.template_id = template_id;
		this.message = message;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTemplate_id() {
		return template_id;
	}
	public void setTemplate_id(String template_id) {
		this.template_id = template_id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "Rescresp [email=" + email + ", template_id=" + template_id + ", message=" + message + "]";
	}
	
	
}
