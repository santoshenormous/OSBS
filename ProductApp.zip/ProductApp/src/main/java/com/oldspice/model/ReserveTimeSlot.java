package com.oldspice.model;

public class ReserveTimeSlot
{

	private String slot_time;
	
	private String notes;
	
	public ReserveTimeSlot()
	{
		
	}

	public ReserveTimeSlot(String slot_time, String notes) {
		super();
		this.slot_time = slot_time;
		this.notes = notes;
	}

	public String getSlot_time() {
		return slot_time;
	}

	public void setSlot_time(String slot_time) {
		this.slot_time = slot_time;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	@Override
	public String toString() {
		return "ReserveTimeSlot [slot_time=" + slot_time + ", notes=" + notes + "]";
	}
	
	
}
