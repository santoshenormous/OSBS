package com.oldspice.model;

public class Price {
	private String sales;
	
}
