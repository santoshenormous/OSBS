package com.oldspice.model;

import java.io.Serializable;

public class ServiceBooking implements Serializable
{

	private static final long serialVersionUID = 1L;
	

	private String date;
	private String guestId;
	private String serviceId;
	private String therapistId;
	
	public ServiceBooking()
	{
		
	}
	public ServiceBooking(String date, String guestId, String serviceId, String therapistId) {
		super();
		
		this.date = date;
		this.guestId = guestId;
		this.serviceId = serviceId;
		this.therapistId = therapistId;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getGuestId() {
		return guestId;
	}
	public void setGuestId(String guestId) {
		this.guestId = guestId;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getTherapistId() {
		return therapistId;
	}
	public void setTherapistId(String therapistId) {
		this.therapistId = therapistId;
	}
	@Override
	public String toString() {
		return "ServiceBooking [date=" + date + ", guestId=" + guestId + ", serviceId=" + serviceId + ", therapistId="
				+ therapistId + "]";
	}
	
	

}
