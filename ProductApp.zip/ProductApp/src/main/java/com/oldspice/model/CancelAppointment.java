package com.oldspice.model;

import java.io.Serializable;

public class CancelAppointment implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String comments;
	private String invoiceId;
	public CancelAppointment()
	{
		
	}
	public CancelAppointment(String comments, String invoiceId) {
		super();
		this.comments = comments;
		this.invoiceId = invoiceId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	@Override
	public String toString() {
		return "CancelAppointment [comments=" + comments + ", invoiceId=" + invoiceId + "]";
	}

	
	
	
	
	

}
