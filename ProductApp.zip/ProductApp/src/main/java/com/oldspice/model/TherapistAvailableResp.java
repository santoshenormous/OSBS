package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class TherapistAvailableResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private TherapistSlots[] therapist_slots;
	
	public TherapistAvailableResp()
	{
		
	}

	public TherapistAvailableResp(TherapistSlots[] therapist_slots) {
		super();
		this.therapist_slots = therapist_slots;
	}

	public TherapistSlots[] getTherapist_slots() {
		return therapist_slots;
	}

	public void setTherapist_slots(TherapistSlots[] therapist_slots) {
		this.therapist_slots = therapist_slots;
	}

	@Override
	public String toString() {
		return "TherapistAvailableResp [therapist_slots=" + Arrays.toString(therapist_slots) + "]";
	}
	
	
	
	
	

}
