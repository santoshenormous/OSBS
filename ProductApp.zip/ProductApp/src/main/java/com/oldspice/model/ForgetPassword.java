package com.oldspice.model;

import java.io.Serializable;

public class ForgetPassword implements Serializable
{

private static final long serialVersionUID = 1L;

private String newPassword;
private String newPasswordConfirm;
private String code;

public ForgetPassword()
{
	
}

public ForgetPassword(String newPassword, String newPasswordConfirm, String code) {
	super();
	this.newPassword = newPassword;
	this.newPasswordConfirm = newPasswordConfirm;
	this.code = code;
}

public String getNewPassword() {
	return newPassword;
}

public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
}

public String getNewPasswordConfirm() {
	return newPasswordConfirm;
}

public void setNewPasswordConfirm(String newPasswordConfirm) {
	this.newPasswordConfirm = newPasswordConfirm;
}

public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

@Override
public String toString() {
	return "ForgetPassword [newPassword=" + newPassword + ", newPasswordConfirm=" + newPasswordConfirm + ", code="
			+ code + "]";
}








}
