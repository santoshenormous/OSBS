package com.oldspice.model;

import java.io.Serializable;

public class TherapistError implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String code;
	private String message;
	public TherapistError()
	{
		
	}
	public TherapistError(String code, String message) {
		super();
		this.code = code;
		this.message = message;
	}
	

}
