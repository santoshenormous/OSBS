package com.oldspice.model;

import java.io.Serializable;

public class AppointmentData implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String guestId;
	
	public AppointmentData()
	{
		
	}

	public AppointmentData(String guestId) {
		super();
		this.guestId = guestId;
	}

	public String getGuestId() {
		return guestId;
	}

	public void setGuestId(String guestId) {
		this.guestId = guestId;
	}

	@Override
	public String toString() {
		return "AppointmentData [guestId=" + guestId + "]";
	}
	
	

}
