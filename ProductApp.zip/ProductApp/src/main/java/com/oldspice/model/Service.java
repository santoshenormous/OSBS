package com.oldspice.model;

public class Service {
	
	private String id;
	private String name;
	private Price price;

}
