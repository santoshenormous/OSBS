package com.oldspice.model;

public class ApiError {

	private int StatusCode;
    private String Message;
    private String message;
    public ApiError()
    {
    	
    }
	public ApiError(int statusCode, String message, String message2) {
		super();
		StatusCode = statusCode;
		Message = message;
		message = message2;
	}
	public int getStatusCode() {
		return StatusCode;
	}
	public void setStatusCode(int statusCode) {
		StatusCode = statusCode;
	}
	
	
	@Override
	public String toString() {
		return "ApiError [StatusCode=" + StatusCode + ", Message=" + Message + ", message=" + message + "]";
	}
	
	
    
}
