package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class GuestDetailsResp implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private GuestDetails[] guests;
	
	public GuestDetailsResp()
	{
		
	}

	public GuestDetailsResp(GuestDetails[] guests) {
		super();
		this.guests = guests;
	}

	public GuestDetails[] getGuests() {
		return guests;
	}

	public void setGuests(GuestDetails[] guests) {
		this.guests = guests;
	}

	@Override
	public String toString() {
		return "GuestDetailsResp [guests=" + Arrays.toString(guests) + "]";
	}


	
	
	
	

}
