package com.oldspice.model;

public class Therapists {

private String id;
private TherapistPersonalInfo personal_info;

public Therapists()
{
	
}

public Therapists(String id, TherapistPersonalInfo personal_info) {
	super();
	this.id = id;
	this.personal_info = personal_info;
}

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public TherapistPersonalInfo getPersonal_info() {
	return personal_info;
}

public void setPersonal_info(TherapistPersonalInfo personal_info) {
	this.personal_info = personal_info;
}

	
}
