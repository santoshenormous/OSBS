package com.oldspice.model;

import java.io.Serializable;

public class CancelServiceResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private boolean success;
	private boolean is_charge_applied;
	
	
	public CancelServiceResp()
	{
		
	}
	public CancelServiceResp(boolean success, boolean is_charge_applied) {
		super();
		this.success = success;
		this.is_charge_applied = is_charge_applied;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public boolean isIs_charge_applied() {
		return is_charge_applied;
	}
	public void setIs_charge_applied(boolean is_charge_applied) {
		this.is_charge_applied = is_charge_applied;
	}
	@Override
	public String toString() {
		return "CancelServiceResp [success=" + success + ", is_charge_applied=" + is_charge_applied + "]";
	}
	
	
	

}
