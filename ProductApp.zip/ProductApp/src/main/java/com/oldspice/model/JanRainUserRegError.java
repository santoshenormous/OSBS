package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class JanRainUserRegError implements Serializable
{
	
private static final long serialVersionUID = 1L;

private String[] emailAddress;
private String[] newPassword;
private String[] signInForm;

public JanRainUserRegError()
{
	
}

public JanRainUserRegError(String[] emailAddress, String[] newPassword, String[] signInForm) {
	super();
	this.emailAddress = emailAddress;
	this.newPassword = newPassword;
	this.signInForm = signInForm;
}

public String[] getEmailAddress() {
	return emailAddress;
}

public void setEmailAddress(String[] emailAddress) {
	this.emailAddress = emailAddress;
}

public String[] getNewPassword() {
	return newPassword;
}

public void setNewPassword(String[] newPassword) {
	this.newPassword = newPassword;
}

public String[] getSignInForm() {
	return signInForm;
}

public void setSignInForm(String[] signInForm) {
	this.signInForm = signInForm;
}

@Override
public String toString() {
	return "JanRainUserRegError [emailAddress=" + Arrays.toString(emailAddress) + ", newPassword="
			+ Arrays.toString(newPassword) + ", signInForm=" + Arrays.toString(signInForm) + "]";
}



}
