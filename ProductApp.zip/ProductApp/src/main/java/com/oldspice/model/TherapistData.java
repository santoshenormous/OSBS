package com.oldspice.model;

import java.io.Serializable;

public class TherapistData implements Serializable
{

private static final long serialVersionUID = 1L;

private String id;
private Integer gender;
private String full_name;
private String first_name;
private String last_name;


public TherapistData()
{
	
}


public TherapistData(String id, Integer gender, String full_name, String first_name, String last_name) {
	super();
	this.id = id;
	this.gender = gender;
	this.full_name = full_name;
	this.first_name = first_name;
	this.last_name = last_name;
}


public String getId() {
	return id;
}


public void setId(String id) {
	this.id = id;
}


public Integer getGender() {
	return gender;
}


public void setGender(Integer gender) {
	this.gender = gender;
}


public String getFull_name() {
	return full_name;
}


public void setFull_name(String full_name) {
	this.full_name = full_name;
}


public String getFirst_name() {
	return first_name;
}


public void setFirst_name(String first_name) {
	this.first_name = first_name;
}


public String getLast_name() {
	return last_name;
}


public void setLast_name(String last_name) {
	this.last_name = last_name;
}


@Override
public String toString() {
	return "TherapistData [id=" + id + ", gender=" + gender + ", full_name=" + full_name + ", first_name=" + first_name
			+ ", last_name=" + last_name + "]";
}




}
