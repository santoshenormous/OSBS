package com.oldspice.model;

import java.io.Serializable;
import java.util.List;

public class SlotBooking implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String GuestId;
	
	private List<TherapistServices> Services;
	
	public SlotBooking()
	{
		
	}

	public SlotBooking(String guestId, List<TherapistServices> services) {
		super();
		GuestId = guestId;
		Services = services;
	}

	public String getGuestId() {
		return GuestId;
	}

	public void setGuestId(String guestId) {
		GuestId = guestId;
	}

	public List<TherapistServices> getServices() {
		return Services;
	}

	public void setServices(List<TherapistServices> services) {
		Services = services;
	}

	@Override
	public String toString() {
		return "SlotBooking [GuestId=" + GuestId + ", Services=" + Services + "]";
	}

	

	
	

}
