package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class CenterResp implements Serializable
{
	private static final long serialVersionUID = 1L;
	private Centers[] centers;
	private String error;

	public CenterResp()
	{
	
	}

	public CenterResp(Centers[] centers, String error) {
		super();
		this.centers = centers;
		this.error = error;
	}

	public Centers[] getCenters() {
		return centers;
	}

	public void setCenters(Centers[] centers) {
		this.centers = centers;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	@Override
	public String toString() {
		return "CenterResp [centers=" + Arrays.toString(centers) + ", error=" + error + "]";
	}
	
	
	

}
