package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class AppointmentsResp implements Serializable
{

	private static final long serialVersionUID = 1L;

	
	private Appointments[] appointments;
	public AppointmentsResp()
	{
		
	}
	public AppointmentsResp(Appointments[] appointments) {
		super();
		this.appointments = appointments;
	}
	public Appointments[] getAppointments() {
		return appointments;
	}
	public void setAppointments(Appointments[] appointments) {
		this.appointments = appointments;
	}
	@Override
	public String toString() {
		return "AppointmentsResp [appointments=" + Arrays.toString(appointments) + "]";
	}
	
	
	
}
