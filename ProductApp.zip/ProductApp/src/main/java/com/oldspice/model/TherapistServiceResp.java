package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class TherapistServiceResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String ServiceId;
	private TherapistsData[] Therapists;
	
	public TherapistServiceResp()
	{
		
	}
	public TherapistServiceResp(String serviceId, TherapistsData[] therapists) {
		super();
		ServiceId = serviceId;
		Therapists = therapists;
	}
	public String getServiceId() {
		return ServiceId;
	}
	public void setServiceId(String serviceId) {
		ServiceId = serviceId;
	}
	public TherapistsData[] getTherapists() {
		return Therapists;
	}
	public void setTherapists(TherapistsData[] therapists) {
		Therapists = therapists;
	}
	@Override
	public String toString() {
		return "TherapistServiceResp [ServiceId=" + ServiceId + ", Therapists=" + Arrays.toString(Therapists) + "]";
	}
	
	
	

}
