package com.oldspice.model;

import java.io.Serializable;

public class EditProfile implements Serializable
{

private static final long serialVersionUID = 1L;

private String firstName;
private String lastName;
private String email;
private String currentPassword;
private String newPassword;
private String newPasswordConfirm;
private String accessToken;


public EditProfile()
{
	
}


public EditProfile(String firstName, String lastName, String email, String currentPassword, String newPassword,
		String newPasswordConfirm, String accessToken) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.currentPassword = currentPassword;
	this.newPassword = newPassword;
	this.newPasswordConfirm = newPasswordConfirm;
	this.accessToken = accessToken;
}



public String getFirstName() {
	return firstName;
}


public void setFirstName(String firstName) {
	this.firstName = firstName;
}


public String getLastName() {
	return lastName;
}


public void setLastName(String lastName) {
	this.lastName = lastName;
}


public String getEmail() {
	return email;
}


public void setEmail(String email) {
	this.email = email;
}


public String getCurrentPassword() {
	return currentPassword;
}


public void setCurrentPassword(String currentPassword) {
	this.currentPassword = currentPassword;
}


public String getNewPassword() {
	return newPassword;
}


public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
}


public String getNewPasswordConfirm() {
	return newPasswordConfirm;
}


public void setNewPasswordConfirm(String newPasswordConfirm) {
	this.newPasswordConfirm = newPasswordConfirm;
}


public String getAccessToken() {
	return accessToken;
}


public void setAccessToken(String accessToken) {
	this.accessToken = accessToken;
}


@Override
public String toString() {
	return "EditProfile [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", currentPassword="
			+ currentPassword + ", newPassword=" + newPassword + ", newPasswordConfirm=" + newPasswordConfirm
			+ ", accessToken=" + accessToken + "]";
}







}
