package com.oldspice.model;

public class Items 
{

	private Item item;
	private TherapistData therapist;
	
	public Items()
	{
		
	}
	public Items(Item item, TherapistData therapist) {
		super();
		this.item = item;
		this.therapist = therapist;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public TherapistData getTherapist() {
		return therapist;
	}
	public void setTherapist(TherapistData therapist) {
		this.therapist = therapist;
	}
	@Override
	public String toString() {
		return "Items [item=" + item + ", therapist=" + therapist + "]";
	}
	
	
	
	
	
	
}
