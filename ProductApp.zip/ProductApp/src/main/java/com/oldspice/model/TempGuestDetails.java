package com.oldspice.model;

public class TempGuestDetails {

	private String tempGuestId;
	private String tempGuestMail;
	private String center_id;
	
	public TempGuestDetails()
	{
		
	}

	public TempGuestDetails(String tempGuestId, String tempGuestMail, String center_id) {
		super();
		this.tempGuestId = tempGuestId;
		this.tempGuestMail = tempGuestMail;
		this.center_id = center_id;
	}

	public String getTempGuestId() {
		return tempGuestId;
	}

	public void setTempGuestId(String tempGuestId) {
		this.tempGuestId = tempGuestId;
	}

	public String getTempGuestMail() {
		return tempGuestMail;
	}

	public void setTempGuestMail(String tempGuestMail) {
		this.tempGuestMail = tempGuestMail;
	}

	public String getCenter_id() {
		return center_id;
	}

	public void setCenter_id(String center_id) {
		this.center_id = center_id;
	}

	@Override
	public String toString() {
		return "TempGuestDetails [tempGuestId=" + tempGuestId + ", tempGuestMail=" + tempGuestMail + ", center_id="
				+ center_id + "]";
	}
	
	
	
	
	 
}
