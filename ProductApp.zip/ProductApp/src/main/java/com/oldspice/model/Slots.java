package com.oldspice.model;

public class Slots {
	
	private String Time;
	private boolean Available;
	
	
	public Slots()
	{
		
	}
	public Slots(String time,boolean available) {
		super();
		Time = time;
	    Available = available;
		
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public boolean isAvailable() {
		return Available;
	}
	public void setAvailable(boolean available) {
		Available = available;
	}
	@Override
	public String toString() {
		return "Slots [Time=" + Time + ", Available=" + Available + "]";
	}
	
	
}
