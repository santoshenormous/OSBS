package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class Appointments implements Serializable
{

	private static final long serialVersionUID = 1L;
	
	private String invoice_id;
	private AppointmentServices[] appointment_services;
	
	public Appointments()
	{
		
	}

	public Appointments(String invoice_id, AppointmentServices[] appointment_services) {
		super();
		this.invoice_id = invoice_id;
		this.appointment_services = appointment_services;
	}

	public String getInvoice_id() {
		return invoice_id;
	}

	public void setInvoice_id(String invoice_id) {
		this.invoice_id = invoice_id;
	}

	public AppointmentServices[] getAppointment_services() {
		return appointment_services;
	}

	public void setAppointment_services(AppointmentServices[] appointment_services) {
		this.appointment_services = appointment_services;
	}

	@Override
	public String toString() {
		return "Appointments [invoice_id=" + invoice_id + ", appointment_services="
				+ Arrays.toString(appointment_services) + "]";
	}

	
	
	
}
