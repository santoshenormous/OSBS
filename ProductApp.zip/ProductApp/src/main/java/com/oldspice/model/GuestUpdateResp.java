package com.oldspice.model;

import java.util.Arrays;

public class GuestUpdateResp {

	private GuestUpdateData[] guests;
	
	public GuestUpdateResp()
	{
		
	}

	public GuestUpdateResp(GuestUpdateData[] guests) {
		super();
		this.guests = guests;
	}

	public GuestUpdateData[] getGuests() {
		return guests;
	}

	public void setGuests(GuestUpdateData[] guests) {
		this.guests = guests;
	}

	@Override
	public String toString() {
		return "GuestUpdateResp [guests=" + Arrays.toString(guests) + "]";
	}
	
	
	
	
	
}
