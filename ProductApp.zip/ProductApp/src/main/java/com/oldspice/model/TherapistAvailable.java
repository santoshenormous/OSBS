package com.oldspice.model;

import java.io.Serializable;

public class TherapistAvailable implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String centerDate;
	private String serviceId;
	
	public TherapistAvailable()
	{
		
	}
	
	public TherapistAvailable(String centerDate, String serviceId) {
		super();
		this.centerDate = centerDate;
		this.serviceId = serviceId;
	}

	public String getCenterDate() {
		return centerDate;
	}

	public void setCenterDate(String centerDate) {
		this.centerDate = centerDate;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	@Override
	public String toString() {
		return "TherapistAvailable [centerDate=" + centerDate + ", serviceId=" + serviceId + "]";
	}
	
	
	
	

}
