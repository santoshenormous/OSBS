package com.oldspice.model;

public class MergeFields {

	private String ServiceType;
	private String UserName;
	private String ServiceTime;
	private String ServiceDate;
	private String BarberName;
	
	public MergeFields()
	{
		
	}
	
	public MergeFields(String serviceType, String userName, String serviceTime, String serviceDate, String barberName) {
		super();
		ServiceType = serviceType;
		UserName = userName;
		ServiceTime = serviceTime;
		ServiceDate = serviceDate;
		BarberName = barberName;
	}

	public String getServiceType() {
		return ServiceType;
	}

	public void setServiceType(String serviceType) {
		ServiceType = serviceType;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getServiceTime() {
		return ServiceTime;
	}

	public void setServiceTime(String serviceTime) {
		ServiceTime = serviceTime;
	}

	public String getServiceDate() {
		return ServiceDate;
	}

	public void setServiceDate(String serviceDate) {
		ServiceDate = serviceDate;
	}

	public String getBarberName() {
		return BarberName;
	}

	public void setBarberName(String barberName) {
		BarberName = barberName;
	}

	@Override
	public String toString() {
		return "MergeFields [ServiceType=" + ServiceType + ", UserName=" + UserName + ", ServiceTime=" + ServiceTime
				+ ", ServiceDate=" + ServiceDate + ", BarberName=" + BarberName + "]";
	}
	
	
	
	
	
}
