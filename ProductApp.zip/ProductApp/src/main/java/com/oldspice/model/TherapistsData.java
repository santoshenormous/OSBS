package com.oldspice.model;

public class TherapistsData {

	private String Id;
	private String Name;
	private String FirstName;
	private String LastName;
	private String ImagePaths;
	private String Email;
	private String BaseCenterId;
	
	public TherapistsData()
	{
		
	}

	public TherapistsData(String id, String name, String firstName, String lastName, String imagePaths, String email,
			String baseCenterId) {
		super();
		Id = id;
		Name = name;
		FirstName = firstName;
		LastName = lastName;
		ImagePaths = imagePaths;
		Email = email;
		BaseCenterId = baseCenterId;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getImagePaths() {
		return ImagePaths;
	}

	public void setImagePaths(String imagePaths) {
		ImagePaths = imagePaths;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getBaseCenterId() {
		return BaseCenterId;
	}

	public void setBaseCenterId(String baseCenterId) {
		BaseCenterId = baseCenterId;
	}

	@Override
	public String toString() {
		return "TherapistsData [Id=" + Id + ", Name=" + Name + ", FirstName=" + FirstName + ", LastName=" + LastName
				+ ", ImagePaths=" + ImagePaths + ", Email=" + Email + ", BaseCenterId=" + BaseCenterId + "]";
	}

	
}
