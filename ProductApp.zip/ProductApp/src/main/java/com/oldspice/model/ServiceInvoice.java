package com.oldspice.model;

import java.io.Serializable;
import java.util.Arrays;

public class ServiceInvoice implements Serializable
{
	private static final long serialVersionUID = 1L;
	private Guest guest;
	private String invoice_id;
	private Items[] items;
	
	
	public ServiceInvoice()
	{
		
	}


	public ServiceInvoice(Guest guest, String invoice_id, Items[] items) {
		super();
		this.guest = guest;
		this.invoice_id = invoice_id;
		this.items = items;
	}

	

	public Guest getGuest() {
		return guest;
	}


	public void setGuest(Guest guest) {
		this.guest = guest;
	}


	public String getInvoice_id() {
		return invoice_id;
	}


	public void setInvoice_id(String invoice_id) {
		this.invoice_id = invoice_id;
	}


	public Items[] getItems() {
		return items;
	}


	public void setItems(Items[] items) {
		this.items = items;
	}


	@Override
	public String toString() {
		return "ServiceInvoice [guest=" + guest + ", invoice_id=" + invoice_id + ", items=" + Arrays.toString(items)
				+ "]";
	}
	
	
	

}
