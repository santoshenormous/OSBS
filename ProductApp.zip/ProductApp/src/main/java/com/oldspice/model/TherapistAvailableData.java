package com.oldspice.model;

import java.io.Serializable;
import java.util.List;

public class TherapistAvailableData implements Serializable
{

	private static final long serialVersionUID = 1L;
	private String CenterId;
	private String CenterDate;
	private List<SlotBooking> SlotBookings;
	
	
	public TherapistAvailableData()
	{
		
	}


	public TherapistAvailableData(String centerId, String centerDate, List<SlotBooking> slotBookings) {
		super();
		CenterId = centerId;
		CenterDate = centerDate;
		SlotBookings = slotBookings;
	}


	public String getCenterId() {
		return CenterId;
	}


	public void setCenterId(String centerId) {
		CenterId = centerId;
	}


	public String getCenterDate() {
		return CenterDate;
	}


	public void setCenterDate(String centerDate) {
		CenterDate = centerDate;
	}


	public List<SlotBooking> getSlotBookings() {
		return SlotBookings;
	}


	public void setSlotBookings(List<SlotBooking> slotBookings) {
		SlotBookings = slotBookings;
	}


	@Override
	public String toString() {
		return "TherapistAvailableData [CenterId=" + CenterId + ", CenterDate=" + CenterDate + ", SlotBookings="
				+ SlotBookings + "]";
	}
	
	
	
	
}
