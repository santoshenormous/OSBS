package com.oldspice.model;

import java.io.Serializable;

public class ServiceConfirm implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String bookingId;
	
	public ServiceConfirm()
	{
		
	}

	public ServiceConfirm(String bookingId) {
		super();
		this.bookingId = bookingId;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	@Override
	public String toString() {
		return "ServiceConfirm [bookingId=" + bookingId + "]";
	}

	
	
	

}
