package com.oldspice.model;

public class PriceInfo {
	private String currency_id;
	private String sale_price;
	private String tax_id;
	
	public PriceInfo()
	{
		
	}
	public PriceInfo(String currency_id, String sale_price, String tax_id) {
		super();
		this.currency_id = currency_id;
		this.sale_price = sale_price;
		this.tax_id = tax_id;
	}
	public String getCurrency_id() {
		return currency_id;
	}
	public void setCurrency_id(String currency_id) {
		this.currency_id = currency_id;
	}
	public String getSale_price() {
		return sale_price;
	}
	public void setSale_price(String sale_price) {
		this.sale_price = sale_price;
	}
	public String getTax_id() {
		return tax_id;
	}
	public void setTax_id(String tax_id) {
		this.tax_id = tax_id;
	}
	
	
	
	

}
