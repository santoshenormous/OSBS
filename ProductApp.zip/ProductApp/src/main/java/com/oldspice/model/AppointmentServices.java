package com.oldspice.model;

import java.io.Serializable;

public class AppointmentServices implements Serializable
{
	
	
	private static final long serialVersionUID = 1L;
	private String appointment_id;
	private String appointment_status;
	private String requested_therapist_id;
	private String therapist_name;
	private String start_time;
	private String end_time;
	private Service service;
	public AppointmentServices()
	{
		
	}
	public AppointmentServices(String appointment_id, String appointment_status, String requested_therapist_id,
			String therapist_name, String start_time, String end_time, Service service) {
		super();
		this.appointment_id = appointment_id;
		this.appointment_status = appointment_status;
		this.requested_therapist_id = requested_therapist_id;
		this.therapist_name = therapist_name;
		this.start_time = start_time;
		this.end_time = end_time;
		this.service = service;
	}
	public String getAppointment_id() {
		return appointment_id;
	}
	public void setAppointment_id(String appointment_id) {
		this.appointment_id = appointment_id;
	}
	public String getAppointment_status() {
		return appointment_status;
	}
	public void setAppointment_status(String appointment_status) {
		this.appointment_status = appointment_status;
	}
	public String getRequested_therapist_id() {
		return requested_therapist_id;
	}
	public void setRequested_therapist_id(String requested_therapist_id) {
		this.requested_therapist_id = requested_therapist_id;
	}
	public String getTherapist_name() {
		return therapist_name;
	}
	public void setTherapist_name(String therapist_name) {
		this.therapist_name = therapist_name;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	public Service getService() {
		return service;
	}
	public void setService(Service service) {
		this.service = service;
	}
	@Override
	public String toString() {
		return "AppointmentServices [appointment_id=" + appointment_id + ", appointment_status=" + appointment_status
				+ ", requested_therapist_id=" + requested_therapist_id + ", therapist_name=" + therapist_name
				+ ", start_time=" + start_time + ", end_time=" + end_time + ", service=" + service + "]";
	}
	
	
	
	
}
