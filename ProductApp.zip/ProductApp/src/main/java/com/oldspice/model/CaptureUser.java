package com.oldspice.model;

public class CaptureUser {
	
	private String givenName;
	private String familyName;
	private String email;
	
	public CaptureUser()
	{
		
	}
	public CaptureUser(String givenName, String familyName, String email) {
		super();
		this.givenName = givenName;
		this.familyName = familyName;
		this.email = email;
	}
	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "CaptureUser [givenName=" + givenName + ", familyName=" + familyName + ", email=" + email + "]";
	}
	
	
	
	

}
