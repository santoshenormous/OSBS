package com.oldspice.model;

public class BookingError {
	
	private String StatusCode;
	private String Message;
	private String InternalMessage;
	
	public BookingError()
	{
		
	}
	public BookingError(String statusCode, String message, String internalMessage) {
		super();
		StatusCode = statusCode;
		Message = message;
		InternalMessage = internalMessage;
	}
	public String getStatusCode() {
		return StatusCode;
	}
	public void setStatusCode(String statusCode) {
		StatusCode = statusCode;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	public String getInternalMessage() {
		return InternalMessage;
	}
	public void setInternalMessage(String internalMessage) {
		InternalMessage = internalMessage;
	}
	@Override
	public String toString() {
		return "BookingError [StatusCode=" + StatusCode + ", Message=" + Message + ", InternalMessage="
				+ InternalMessage + "]";
	}
	
	
	

}
