package com.oldspice.model;

import java.io.Serializable;

public class ResetEmail implements Serializable
{

private static final long serialVersionUID = 1L;

private String code;
private String updatedEmail;

public ResetEmail()
{
	
}

public ResetEmail(String code, String updatedEmail) {
	super();
	this.code = code;
	this.updatedEmail = updatedEmail;
}

public String getCode() {
	return code;
}

public void setCode(String code) {
	this.code = code;
}

public String getUpdatedEmail() {
	return updatedEmail;
}

public void setUpdatedEmail(String updatedEmail) {
	this.updatedEmail = updatedEmail;
}

@Override
public String toString() {
	return "ResetEmail [code=" + code + ", updatedEmail=" + updatedEmail + "]";
}





}
