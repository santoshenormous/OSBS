package com.oldspice.model;

public class GuestUpdateData {
	
	 private String id;
	 private String center_id;
	 private  GuestPersonalInfo personal_info;
	 
	 public GuestUpdateData()
	 {
		 
	 }
	 
	public GuestUpdateData(String id, String center_id, GuestPersonalInfo personal_info) {
		super();
		this.id = id;
		this.center_id = center_id;
		this.personal_info = personal_info;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCenter_id() {
		return center_id;
	}

	public void setCenter_id(String center_id) {
		this.center_id = center_id;
	}

	public GuestPersonalInfo getPersonal_info() {
		return personal_info;
	}

	public void setPersonal_info(GuestPersonalInfo personal_info) {
		this.personal_info = personal_info;
	}

	@Override
	public String toString() {
		return "GuestUpdateData [id=" + id + ", center_id=" + center_id + ", personal_info=" + personal_info + "]";
	}
	
	
	 
	 

}
