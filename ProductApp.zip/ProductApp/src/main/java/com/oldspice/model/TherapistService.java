package com.oldspice.model;

public class TherapistService {

	private String Id;

	public TherapistService()
	{
		
	}

	public TherapistService(String id) {
		super();
		Id = id;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	@Override
	public String toString() {
		return "TherapistService [Id=" + Id + "]";
	}
	
	
	
}
