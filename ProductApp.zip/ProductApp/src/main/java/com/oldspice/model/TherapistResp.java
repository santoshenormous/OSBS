package com.oldspice.model;

import java.io.Serializable;

public class TherapistResp implements Serializable
{

private static final long serialVersionUID = 1L;

private Therapists[] therapists;

public TherapistResp()
{
	
}

public TherapistResp(Therapists[] therapists) {
	super();
	this.therapists = therapists;
}

public Therapists[] getTherapists() {
	return therapists;
}

public void setTherapists(Therapists[] therapists) {
	this.therapists = therapists;
}






}
