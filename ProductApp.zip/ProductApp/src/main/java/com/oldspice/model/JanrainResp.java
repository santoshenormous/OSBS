package com.oldspice.model;

import java.io.Serializable;

public class JanrainResp implements Serializable
{

	private static final long serialVersionUID = 1L;
	private CaptureUser capture_user;
	private String stat;
	private String access_token;
   private GuestDetails guests;
	
	public JanrainResp()
	{
		
	}

	public JanrainResp(CaptureUser capture_user, String stat, String access_token, GuestDetails guests) {
		super();
		this.capture_user = capture_user;
		this.stat = stat;
		this.access_token = access_token;
		this.guests = guests;
	}

	public CaptureUser getCapture_user() {
		return capture_user;
	}

	public void setCapture_user(CaptureUser capture_user) {
		this.capture_user = capture_user;
	}

	public String getStat() {
		return stat;
	}

	public void setStat(String stat) {
		this.stat = stat;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public GuestDetails getGuests() {
		return guests;
	}

	public void setGuests(GuestDetails guests) {
		this.guests = guests;
	}

	@Override
	public String toString() {
		return "JanrainResp [capture_user=" + capture_user + ", stat=" + stat + ", access_token=" + access_token
				+ ", guests=" + guests + "]";
	}
	
	
	
	
}
