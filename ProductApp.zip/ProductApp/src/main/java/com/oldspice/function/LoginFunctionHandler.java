package com.oldspice.function;

import java.util.Optional;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.oldspice.model.EditProfile;
import com.oldspice.model.ForgetPassword;
import com.oldspice.model.GuestUpdateResp;
import com.oldspice.model.JanRainUser;
import com.oldspice.model.JanrainLogin;
import com.oldspice.model.JanrainLoginResp;
import com.oldspice.model.PersonalInfo;
import com.oldspice.model.ResetPassword;
import com.oldspice.model.SendRestCodeToMail;
import com.oldspice.model.TokenResp;
import com.oldspice.model.ZenotiUser;
import com.oldspice.service.LoginService;
import com.oldspice.service.ProductService;
import com.oldspice.util.ProductUtil;

public class LoginFunctionHandler {

	Logger logger = Logger.getLogger(LoginFunctionHandler.class);
	
	
	@FunctionName("userRegister")
	public HttpResponseMessage userRegister(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<JanRainUser>> request,
			final ExecutionContext context) throws Exception {

		logger.info("userRegister HTTP trigger processed a request.");

		try {
			JanRainUser user = request.getBody().get();

			String janrainResult = LoginService.userRegister(ProductUtil.registerurl, user);

			JanrainLoginResp janrainResp = new Gson().fromJson(janrainResult, JanrainLoginResp.class);
			
			GuestUpdateResp guestDetailsResp = ProductService.getGuestDetails(ProductUtil.zenotiGuestSearch, user.getEmailAddress());
			
			
			if (!janrainResult.contains("error") && guestDetailsResp.getGuests().length==0) {
				

				  logger.info("enter guest not exist");
				  ZenotiUser zenotiUser=new ZenotiUser(); 
				  PersonalInfo personalInfo=new PersonalInfo(); 
				  personalInfo.setFirst_name(user.getFirstName());
				  personalInfo.setLast_name(user.getLastName());
				  personalInfo.setEmail(user.getEmailAddress()); 
				  personalInfo.setGender(1);
				  zenotiUser.setCenter_id(ProductUtil.centerId);
				  zenotiUser.setPersonal_info(personalInfo);
				  
				  String bookingData = new Gson().toJson(zenotiUser);
				  ProductService.createGuest(ProductUtil.zenotiGuests,bookingData);
				
				  GuestUpdateResp getGuestDetails =ProductService.getGuestDetails(ProductUtil.zenotiGuestSearch, user.getEmailAddress());
				  janrainResp.setGuests(getGuestDetails.getGuests());
				 

			}
			if (!janrainResult.contains("error") && guestDetailsResp.getGuests().length>0) {
				logger.info("enter zenoti guest exist");
				janrainResp.setGuests(guestDetailsResp.getGuests());
			}
			
			return request.createResponseBuilder(HttpStatus.CREATED).body(janrainResp).build();

		} catch (Exception e) {
			logger.error("error in userRegister==" + e.getMessage());
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}

	}

	@FunctionName("signIn")
	public HttpResponseMessage signIn(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<JanrainLogin>> request,
			final ExecutionContext context) throws Exception {

		logger.info("signIn HTTP trigger processed a request.");

		try {
			JanrainLogin login = request.getBody().get();


			String janrainResult = LoginService.signIn(ProductUtil.signInUrl,login);

			JanrainLoginResp janrainResp = new Gson().fromJson(janrainResult, JanrainLoginResp.class);
			
			if (!janrainResult.contains("error"))
			{
				
				GuestUpdateResp guestDetailsResp = ProductService.getGuestDetails(ProductUtil.zenotiGuestSearch, login.getSignInEmailAddress());
				janrainResp.setGuests(guestDetailsResp.getGuests());
			
			}

			return request.createResponseBuilder(HttpStatus.OK).body(janrainResp).build();

		} catch (Exception e) {
			logger.error("error in signIn" + e.getMessage());
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}

	}

	@FunctionName("sendResetCodeToMail")
	public HttpResponseMessage sendResetCodeToMail(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<SendRestCodeToMail>> request,
			final ExecutionContext context) throws Exception {

		logger.info("sendResetCodeToMail HTTP trigger processed a request.");

		try {

			SendRestCodeToMail sendRestCodeToMail = request.getBody().get();

			String janrainResult = LoginService.sendPasswordResetCodeToMail(
					ProductUtil.sendPasswordresetcodetoMailUrl, sendRestCodeToMail);

			return request.createResponseBuilder(HttpStatus.OK).body(janrainResult).build();
		} catch (Exception e) {
			logger.error("error in sendResetCodeToMail" + e.getMessage());
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}

	}

	@FunctionName("resetPassword")
	public HttpResponseMessage resetPassword(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<ForgetPassword>> request,
			final ExecutionContext context) throws Exception {

		logger.info("resetPassword HTTP trigger processed a request.");
		try {
			ForgetPassword resetPassword = request.getBody().get();

			
			String res = LoginService.getoauthToken(ProductUtil.oauthtokenUrl,
					resetPassword.getCode());
			
			TokenResp tokenResp = new Gson().fromJson(res, TokenResp.class);
			
			resetPassword.setCode(tokenResp.getAccess_token());

           String janrainResult = LoginService.resetPassword(ProductUtil.resetpasswordUrl, resetPassword);
			

			return request.createResponseBuilder(HttpStatus.OK).body(janrainResult).build();

		} catch (Exception e) {
			logger.error("error in resetPassword" + e.getMessage());
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}

	}

	@FunctionName("editProfile")
	public HttpResponseMessage editProfile(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<EditProfile>> request,
			final ExecutionContext context) throws Exception {

		logger.info("editProfile HTTP trigger processed a request.");
		try {
			EditProfile editProfile = request.getBody().get();
			
			String janrainResult="";
			
			if(!editProfile.getFirstName().isEmpty())
			{
			janrainResult=LoginService.editProfile(ProductUtil.resetpasswordUrl, editProfile);
			}
			
			
			if(!editProfile.getCurrentPassword().isEmpty() && !editProfile.getNewPassword().isEmpty() && !editProfile.getNewPasswordConfirm().isEmpty())
			{
				
				
				JanrainLogin janrainLogin=new JanrainLogin();
				janrainLogin.setSignInEmailAddress(editProfile.getEmail());
				janrainLogin.setCurrentPassword(editProfile.getCurrentPassword());
				
				String loginResult = LoginService.signIn(ProductUtil.signInUrl,janrainLogin);
				
				if (!loginResult.contains("error"))
				{
					
					ResetPassword resetPassword = new ResetPassword();
			        resetPassword.setCode(editProfile.getAccessToken());
					resetPassword.setNewPassword(editProfile.getNewPassword());
					resetPassword.setNewPasswordConfirm(editProfile.getNewPasswordConfirm());
					resetPassword.setCurrentPassword(editProfile.getCurrentPassword());
					janrainResult=LoginService.resetPasswordForEditProfile(ProductUtil.resetpasswordUrl, resetPassword);	
					
				}
				else
				{
					janrainResult =loginResult;
				}
				
			
				
			}
			

			
			return request.createResponseBuilder(HttpStatus.OK).body(janrainResult).build();

		} catch (Exception e) {
			logger.error("error in editProfile" + e.getMessage());
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}

	}
	
	
	
	

}
