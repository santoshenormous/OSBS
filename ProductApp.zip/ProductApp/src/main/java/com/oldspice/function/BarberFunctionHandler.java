package com.oldspice.function;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.oldspice.model.ApiResp;
import com.oldspice.model.AppointmentData;
import com.oldspice.model.BookingResp;
import com.oldspice.model.CancelAppointment;
import com.oldspice.model.CancelService;
import com.oldspice.model.CenterResp;
import com.oldspice.model.GuestDetails;
import com.oldspice.model.GuestUpdate;
import com.oldspice.model.GuestUpdateReq;
import com.oldspice.model.GuestUpdateResp;
import com.oldspice.model.Guests;
import com.oldspice.model.Item;
import com.oldspice.model.Items;
import com.oldspice.model.MergeFields;
import com.oldspice.model.PersonalInfo;
import com.oldspice.model.RescReq;
import com.oldspice.model.Rescresp;
import com.oldspice.model.ReserveSlot;
import com.oldspice.model.ReserveTimeSlot;
import com.oldspice.model.ResetEmail;
import com.oldspice.model.ServiceBooking;
import com.oldspice.model.ServiceBookingResp;
import com.oldspice.model.ServiceConfirm;
import com.oldspice.model.SingleGuestUpdateReq;
import com.oldspice.model.SlotBooking;
import com.oldspice.model.TempGuestDetails;
import com.oldspice.model.TherapistAvailable;
import com.oldspice.model.TherapistAvailableData;
import com.oldspice.model.TherapistData;
import com.oldspice.model.TherapistService;
import com.oldspice.model.TherapistServiceResp;
import com.oldspice.model.TherapistServices;
import com.oldspice.model.TokenResp;
import com.oldspice.model.UserMailTemplate;
import com.oldspice.model.ZenotiUser;
import com.oldspice.service.LoginService;
import com.oldspice.service.ProductService;
import com.oldspice.util.ProductUtil;

public class BarberFunctionHandler {

	Logger logger = Logger.getLogger(BarberFunctionHandler.class);
	
	
	Gson gson = new GsonBuilder().serializeNulls().create();
	
	@FunctionName("getCenters")
    public HttpResponseMessage getCenters(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<CenterResp>> request,
            final ExecutionContext context) throws Exception {
		 
        logger.info("getCenters HTTP trigger processed a request.");
       
        try
        {
        	CenterResp	centerResp  = ProductService.getCenters(ProductUtil.zenotiCenters);
        	
           return request.createResponseBuilder(HttpStatus.OK).body(centerResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getCenters=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("getServices")
    public HttpResponseMessage getServices(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<CenterResp>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("getServices HTTP trigger processed a request.");
        
       
        try
        {
        	
        	Object	serviceResp  = ProductService.getServices(ProductUtil.zenotiCenters);
        	
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(gson.toJson(serviceResp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getServices=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	
	@FunctionName("getTherapists")
    public HttpResponseMessage getBarbers(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<CenterResp>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("getTherapists HTTP trigger processed a request.");
        
       
        try
        {
        	
        	Object	barberResp  = ProductService.getTherapists(ProductUtil.zenotiCenters);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(barberResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getTherapists=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("generateBookingId")
    public HttpResponseMessage generateBookingId(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<ServiceBooking>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("generateBookingId HTTP trigger processed a request.");
        
       
        try
        {
        ServiceBooking serviceBooking=request.getBody().get();
        ServiceBookingResp serviceBookingResp=new ServiceBookingResp();
        
        	
            Guests guest=new Guests();
        	List<Guests> ls=new ArrayList<>();
        	List<Items> itemsList=new ArrayList<>();
        	TherapistData therapistData=new TherapistData();
        	if(serviceBooking.getTherapistId().isEmpty())
        	{
        		therapistData.setId(null);	
        	}
        	else
        	{
        		therapistData.setId(serviceBooking.getTherapistId());
        	}
        	
        	therapistData.setGender(0);
        	Item item=new Item();
        	item.setId(serviceBooking.getServiceId());
        	Items items=new Items();
        	items.setItem(item);
        	items.setTherapist(therapistData);
        	itemsList.add(items);
        	guest.setId(serviceBooking.getGuestId());
        	guest.setItems(itemsList);
        	ls.add(guest);
        	serviceBookingResp.setCenter_id(ProductUtil.centerId);
        	serviceBookingResp.setDate(serviceBooking.getDate());
        	serviceBookingResp.setIs_only_catalog_employees("true");
        	serviceBookingResp.setGuests(ls);
        	
        	String bookingData = new Gson().toJson(serviceBookingResp);
        	BookingResp	bookingResp  = ProductService.generateBookingId(ProductUtil.zenotiBookingid,bookingData);
        	
        	
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(bookingResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getServices=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("getTimeSlots")
    public HttpResponseMessage getTimeSlots(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<String>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("getTimeSlots HTTP trigger processed a request.");
        
       
        try
        {
        	
        	String bookingId= request.getQueryParameters().get("bookingid");
        
        	Object	slotsResp  = ProductService.getTimeSlots(ProductUtil.zenotiBookingid,bookingId);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(slotsResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getTimeSlots=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	
	@FunctionName("reserveTimeSlot")
    public HttpResponseMessage reserveTimeSlot(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<ReserveSlot>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("reserveTimeSlot HTTP trigger processed a request.");
        
       
        try
        {
        	ReserveSlot reserveSlot=request.getBody().get();
        	ReserveTimeSlot reserveTimeSlot=new ReserveTimeSlot();
        	
        	reserveTimeSlot.setSlot_time(reserveSlot.getTimeSlot());
        	reserveTimeSlot.setNotes("Reserve the service booking on this date and time");
        	
        	
        	String bookingData = new Gson().toJson(reserveTimeSlot);
        	
        	Object	slotReserveResp  = ProductService.getReserveTimeSlot(ProductUtil.zenotiBookingid,reserveSlot.getBookingId(),bookingData);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(slotReserveResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in reserveTimeSlot=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("therapistAvailablity")
    public HttpResponseMessage therapistAvailablity(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<TherapistAvailable>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("reserveTimeSlot HTTP trigger processed a request.");
        
       
        try
        {
        	TherapistAvailable therapistAvailableReq=request.getBody().get();
        	
        	
        	TherapistAvailableData therapistAvailableData=new TherapistAvailableData(); 
        	therapistAvailableData.setCenterId(ProductUtil.centerId);
        	therapistAvailableData.setCenterDate(therapistAvailableReq.getCenterDate());
        	List<SlotBooking> slotbookingsList=new ArrayList<SlotBooking>();
        	List<TherapistServices> therapistServicesList=new ArrayList<TherapistServices>();
        	TherapistService therapistService=new TherapistService();
        	therapistService.setId(therapistAvailableReq.getServiceId());
        	TherapistServices therapistServices=new TherapistServices();
        	therapistServices.setService(therapistService);
        	therapistServicesList.add(therapistServices);
        	SlotBooking slotBooking=new SlotBooking();
        	slotBooking.setGuestId("");
        	slotBooking.setServices(therapistServicesList);
        	slotbookingsList.add(slotBooking);
        	therapistAvailableData.setSlotBookings(slotbookingsList);
        	String bookingData = new Gson().toJson(therapistAvailableData);
        	Object	therapistAvailableResp  = ProductService.therapistAvailablity(ProductUtil.zenotiTherapistavailable,bookingData);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(therapistAvailableResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in reserveTimeSlot=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("confirmSlot")
    public HttpResponseMessage confirmSlot(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<ServiceConfirm>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("confirmSlot HTTP trigger processed a request.");
        
       
        try
        {
        	ServiceConfirm serviceConfirm=request.getBody().get();
        	
        	Object	slotReserveResp  = ProductService.confirSlot(ProductUtil.zenotiBookingid,serviceConfirm.getBookingId());
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(slotReserveResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in confirmSlot=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	@FunctionName("appointmentDetails")
    public HttpResponseMessage getAppointmentDetails(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<AppointmentData>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("appointmentDetails HTTP trigger processed a request.");
        
       
        try
        {
        	AppointmentData appointmentData=request.getBody().get();
        	
        	Object	appointmentResp  = ProductService.getAppointmentDetails(ProductUtil.zenotiGuests,appointmentData.getGuestId());
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(appointmentResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in appointmentDetails=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	@FunctionName("cancelAppointment")
    public HttpResponseMessage cancelAppointment(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<CancelService>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("cancelAppointment HTTP trigger processed a request.");
        
       
        try
        {
        	CancelService CancelService=request.getBody().get();
        	CancelAppointment cancelAppointment=new CancelAppointment();
        	cancelAppointment.setComments("cancel appointment");
        	String bookingData = new Gson().toJson(cancelAppointment);
        	
        	
        	
        	Object	cancelResp  = ProductService.cancelAppointmet(ProductUtil.zenotiCancelappointment,bookingData,CancelService.getInvoiceId());
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(cancelResp).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in cancelAppointment=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("getTherapistsByServiceId")
    public HttpResponseMessage getTherapistsByServiceId(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<TherapistServiceResp>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("getTherapistsByServiceId HTTP trigger processed a request.");
        
       
        try
        {
        	String serviceId= request.getQueryParameters().get("serviceId");
        	
        	TherapistServiceResp	barberResp  = ProductService.getTherapistsByServiceId(ProductUtil.zenotiTherapists,serviceId);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(gson.toJson(barberResp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getTherapistsByServiceId=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	@FunctionName("generateTempGuestId")
    public HttpResponseMessage generateTempGuestId(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<TempGuestDetails>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("generateTempGuestId HTTP trigger processed a request.");
        
       
        try
        {
        	 Random rand = new Random(); 
             int rand_int = rand.nextInt(1000); 
             String email="osbstempguest"+rand_int+"@gmail.com";
              ZenotiUser zenotiUser=new ZenotiUser(); 
        	  TempGuestDetails tempGuestDetails=new TempGuestDetails();
			  PersonalInfo personalInfo=new PersonalInfo(); 
			  personalInfo.setFirst_name("osbstempguest");
			  personalInfo.setLast_name("osbs");
			  personalInfo.setEmail(email); 
			  personalInfo.setGender(1);
			  zenotiUser.setCenter_id(ProductUtil.centerId);
			  zenotiUser.setPersonal_info(personalInfo);
			  
			  String bookingData = new Gson().toJson(zenotiUser);
			  GuestDetails guestDetails =ProductService.createGuest(ProductUtil.zenotiGuests,bookingData);
			  tempGuestDetails.setTempGuestId(guestDetails.getId());
			  tempGuestDetails.setTempGuestMail(email);
			  tempGuestDetails.setCenter_id(guestDetails.getCenter_id());
			  String tempGuestData = new Gson().toJson(tempGuestDetails);
			  
        	return request.createResponseBuilder(HttpStatus.OK).body(tempGuestData).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in generateTempGuestId=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	
	@FunctionName("bookingemailconfirm")
    public HttpResponseMessage confirmAppointmentMail(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<RescReq>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("confirmAppointmentMail HTTP trigger processed a request.");
        
       
        try
        {
        	RescReq rescReq=request.getBody().get();
        	
        	UserMailTemplate userMailTemplate=new UserMailTemplate();
        	MergeFields mergeFields=new MergeFields();
        	
        	mergeFields.setBarberName(rescReq.getBarberName());
        	mergeFields.setServiceDate(rescReq.getServiceDate());
        	mergeFields.setServiceTime(rescReq.getServiceTime());
        	mergeFields.setServiceType(rescReq.getServiceType());
        	mergeFields.setUserName(rescReq.getUserName());
        	
        	userMailTemplate.setTemplate_id(8);
        	userMailTemplate.setEmail(rescReq.getEmail());
        	userMailTemplate.setMerge_fields(mergeFields);
        	userMailTemplate.setAccepts_marketing(rescReq.getAccepts_marketing());
        	
        	String bookingData = new Gson().toJson(userMailTemplate);
        	
        	
        	 
        	Rescresp rescresp  = ProductService.confirmAppointmentMail(ProductUtil.transactionalSends,bookingData);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(new Gson().toJson(rescresp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in confirmAppointmentMail=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	
	
	@FunctionName("bookingemailcancel")
    public HttpResponseMessage cancelAppointmentMail(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<RescReq>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("cancelAppointmentMail HTTP trigger processed a request.");
        
       
        try
        {
        	RescReq rescReq=request.getBody().get();
        	
        	UserMailTemplate userMailTemplate=new UserMailTemplate();
        	MergeFields mergeFields=new MergeFields();
        	
        	mergeFields.setBarberName(rescReq.getBarberName());
        	mergeFields.setServiceDate(rescReq.getServiceDate());
        	mergeFields.setServiceTime(rescReq.getServiceTime());
        	mergeFields.setServiceType(rescReq.getServiceType());
        	mergeFields.setUserName(rescReq.getUserName());
        	
        	userMailTemplate.setTemplate_id(9);
        	userMailTemplate.setEmail(rescReq.getEmail());
        	userMailTemplate.setMerge_fields(mergeFields);
        	userMailTemplate.setAccepts_marketing(rescReq.getAccepts_marketing());
        	
        	String bookingData = new Gson().toJson(userMailTemplate);
        	 
        	Rescresp rescresp  = ProductService.confirmAppointmentMail(ProductUtil.transactionalSends,bookingData);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(new Gson().toJson(rescresp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in cancelAppointmentMail=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
	
	

    @FunctionName("updateGuestDetails")
    public HttpResponseMessage updateGuestDetails(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<GuestUpdateReq>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("updateGuestDetails HTTP trigger processed a request.");
        
       
        try
        {
        	
        	
        	GuestUpdateReq guestUpdateReq=request.getBody().get();
			 
        	GuestUpdateResp guestDetailsResp=	ProductService.getGuestDetails(ProductUtil.zenotiGuestSearch, guestUpdateReq.getSearchEmail());
        
        	ApiResp apiResp=new ApiResp();
        	if(guestDetailsResp.getGuests().length>0)
        	{
        		
        	apiResp.setMessage("ok");
        	GuestUpdate guestUpdate=new GuestUpdate();
        	PersonalInfo pInfo=new PersonalInfo();
        	pInfo.setFirst_name(guestUpdateReq.getFirstName());
        	pInfo.setLast_name(guestUpdateReq.getLastName());
        	pInfo.setEmail(guestUpdateReq.getUpdateEmail());
        	guestUpdate.setCenter_id(ProductUtil.centerId);
        	guestUpdate.setPersonal_info(pInfo);
        	String bookingData = new Gson().toJson(guestUpdate);
        	 
        	Arrays.stream(guestDetailsResp.getGuests()).forEach((e)->{
        
        	
			try {
				
				GuestUpdate guestUpdateResp=	ProductService.updateGuest(ProductUtil.zenotiGuests, bookingData, e.getId());
				
				if(null==guestUpdateResp.getCenter_id())
				{
					apiResp.setMessage("error");	
				}
				
			} catch (IOException e1) {
				
			}
			});
        	
        	
        	
        }
        	else
        	{
        	
        		apiResp.setMessage("no data found with email");
        	}


        	return request.createResponseBuilder(HttpStatus.OK).body(new Gson().toJson(apiResp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in updateGuestDetails=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
    
   
    
    
    @FunctionName("updateEmail")
	public HttpResponseMessage updateEmail(@HttpTrigger(name = "req", methods = {
			HttpMethod.POST }, authLevel = AuthorizationLevel.FUNCTION) HttpRequestMessage<Optional<ResetEmail>> request,
			final ExecutionContext context) throws Exception {

		   logger.info("updateEmail HTTP trigger processed a request.");
		
		   try {
			
			ResetEmail resetEmail = request.getBody().get();
			
		    String res = LoginService.getoauthToken(ProductUtil.oauthtokenUrl,resetEmail.getCode());
			
			TokenResp tokenResp = new Gson().fromJson(res, TokenResp.class);
			
			String janrainResult=ProductService.ResetEmail(ProductUtil.resetpasswordUrl, resetEmail,tokenResp.getAccess_token());
			
			return request.createResponseBuilder(HttpStatus.OK).body(janrainResult).build();

		} catch (Exception e) {
			logger.error("error in updateEmail" + e.getMessage());
			return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
		}

    }
    
    
    
    @FunctionName("updateGuest")
    public HttpResponseMessage updateSingleGuestDetails(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.POST},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<SingleGuestUpdateReq>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("updateGuestDetails HTTP trigger processed a request.");
        
       
        try
        {
        	
        	
        	SingleGuestUpdateReq singleGuestUpdateReq=request.getBody().get();
        	ApiResp apiResp=new ApiResp();
        	apiResp.setMessage("ok");
        	GuestUpdate guestUpdate=new GuestUpdate();
        	PersonalInfo pInfo=new PersonalInfo();
        	pInfo.setFirst_name(singleGuestUpdateReq.getFirstName());
        	pInfo.setLast_name(singleGuestUpdateReq.getLastName());
        	pInfo.setEmail(singleGuestUpdateReq.getEmail());
        	guestUpdate.setCenter_id(ProductUtil.centerId);
        	guestUpdate.setPersonal_info(pInfo);
        	String bookingData = new Gson().toJson(guestUpdate);
        	
				GuestUpdate guestUpdateResp=	ProductService.updateGuest(ProductUtil.zenotiGuests, bookingData,singleGuestUpdateReq.getGuestId());
				if(null==guestUpdateResp.getCenter_id())
				{
					apiResp.setMessage("error");	
				}
			
        	return request.createResponseBuilder(HttpStatus.OK).body(new Gson().toJson(apiResp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in updateGuestDetails=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
    
    
    @FunctionName("getGuestDataByEmail")
    public HttpResponseMessage getGuestDataByEmail(
            @HttpTrigger(
                name = "req",
                methods = {HttpMethod.GET},
                authLevel = AuthorizationLevel.FUNCTION)
                HttpRequestMessage<Optional<GuestUpdateResp>> request,
            final ExecutionContext context) throws Exception {
	 
        logger.info("getGuestDataByEmail HTTP trigger processed a request.");
        
       
        try
        {
        	String email= request.getQueryParameters().get("email");
        	
        	GuestUpdateResp guestDetailsResp = ProductService.getGuestDetails(ProductUtil.zenotiGuestSearch, email);
        	
        	return request.createResponseBuilder(HttpStatus.OK).body(gson.toJson(guestDetailsResp)).build();
           
        	
     } catch (Exception e) {
    	  logger.error("error in getGuestDataByEmail=="+e.getMessage());
    	  return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body(null).build();
    }
		
    }
    
    
}
