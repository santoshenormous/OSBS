package com.oldspice.util;

public class ProductUtil {

	public static final String clientId="peqs6fpqed9k2qtydqxjggwn29reh6e3";
	public static final String clientSecret="ejk4g9z3u2727mrvwj4utechn4sja7ms";
	public static final String signInUrl="https://procter-gamble.us-dev.janraincapture.com/oauth/auth_native_traditional";
	public static final String sendPasswordresetcodetoMailUrl="https://procter-gamble.us-dev.janraincapture.com/oauth/forgot_password_native";
	public static final String oauthtokenUrl="https://procter-gamble.us-dev.janraincapture.com/oauth/token";
	public static final String resetpasswordUrl="https://procter-gamble.us-dev.janraincapture.com/oauth/update_profile_native";
	public static final String registerurl="https://procter-gamble.us-dev.janraincapture.com/oauth/register_native_traditional";
	public static final String loginFlowVersion="20201020133855333002";
	public static final String loginOauthRedirectUrl="https://oldspicebarbershop-prod-staging.azurewebsites.net/reset-password";
	
	
	public static final String centerId="98f8aa5b-bc8e-4f2d-834f-fa13af0bb6d7";
    public static final String zenotiAccessKey="fd05b7be68ab47a1aae6e8276e13a80bfdd00757738b451ca6e4a1d4147757e9";
	public static final String zenotiGuests="https://api.zenoti.com/v1/guests";
	public static final String zenotiGuestSearch="https://api.zenoti.com/v1/guests/search";
	public static final String zenotiCenters="https://api.zenoti.com/v1/centers";
	public static final String zenotiBookingid="https://api.zenoti.com/v1/bookings";
	public static final String zenotiTherapistavailable="https://api.zenoti.com/v1/appointments/therapist_availability";
	public static final String zenotiCancelappointment="https://api.zenoti.com/v1/invoices";
	public static final String zenotiTherapists="https://apiamrs09.zenoti.com/api/Catalog/Therapists";
	public static final String transactionalSends="https://data.retentionscience.com/v3/transactional_sends";
	public static final String rescKey="e4af120044717eba14285f63b73ae96f14618d9df433ad5a0c5a6edfe722e837";
	
	
}
