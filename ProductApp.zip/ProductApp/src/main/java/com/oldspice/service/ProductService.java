package com.oldspice.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHeaders;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.oldspice.model.ApiError;
import com.oldspice.model.AppointmentServices;
import com.oldspice.model.Appointments;
import com.oldspice.model.AppointmentsResp;
import com.oldspice.model.BookingError;
import com.oldspice.model.BookingResp;
import com.oldspice.model.CancelServiceResp;
import com.oldspice.model.CenterResp;
import com.oldspice.model.GuestDetails;
import com.oldspice.model.GuestUpdate;
import com.oldspice.model.GuestUpdateResp;
import com.oldspice.model.Rescresp;
import com.oldspice.model.ResetEmail;
import com.oldspice.model.ServiceConfirmResp;
import com.oldspice.model.ServiceResp;
import com.oldspice.model.SlotReserveResp;
import com.oldspice.model.SlotsResp;
import com.oldspice.model.TherapistAvailableResp;
import com.oldspice.model.TherapistError;
import com.oldspice.model.TherapistResp;
import com.oldspice.model.TherapistServiceResp;
import com.oldspice.util.ProductUtil;


public class ProductService {

	
	
	  public static CenterResp getCenters(String url) throws IOException {

		    
	        HttpGet httpReq = new HttpGet(url);
	        String auth=ProductUtil.zenotiAccessKey;
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
	        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	        CloseableHttpResponse response = httpClient. execute(httpReq);
            String result = EntityUtils.toString(response.getEntity());
	         CenterResp centerResp =  new Gson().fromJson(result, CenterResp.class);
	          
	         return centerResp;
	    }
	  
	  
	  public static Object getServices(String url) throws IOException {

		   
		    url=url+"/"+ProductUtil.centerId+"/services";
	        HttpGet httpReq = new HttpGet(url);
	      
	        String auth=ProductUtil.zenotiAccessKey;
	       
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			  
			
	        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	               
	        CloseableHttpResponse response = httpClient. execute(httpReq);

	         String result = EntityUtils.toString(response.getEntity());
	         
	         if(response.getStatusLine().getStatusCode()==200)
	         {
	        	 ServiceResp  serviceResp =  new Gson().fromJson(result, ServiceResp.class);
	        	
	        	 return serviceResp;
	         }
	         else
	         {
	        	 ApiError  apiError =  new Gson().fromJson(result, ApiError.class); 
	        	 apiError.setStatusCode(response.getStatusLine().getStatusCode());
	        	 return apiError;
	         }
	            
	        
	         
	      
	    }
	  
	  
	  public static Object getTherapists(String url) throws IOException {

		    url=url+"/"+ProductUtil.centerId+"/therapists";
		    HttpGet httpReq = new HttpGet(url);
	      
	       String auth=ProductUtil.zenotiAccessKey;
		   
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	       
			CloseableHttpResponse response = httpClient. execute(httpReq);
           
			String result = EntityUtils.toString(response.getEntity());
           
		
			
			 if(response.getStatusLine().getStatusCode()==200)
	         {
					TherapistResp  therapistResp =  new Gson().fromJson(result, TherapistResp.class);
	        	 return therapistResp;
	         }
	         else
	         {
	        	 ApiError  apiError =  new Gson().fromJson(result, ApiError.class); 
	        	 apiError.setStatusCode(response.getStatusLine().getStatusCode());
	        	 return apiError;
	         }
	        
	    }
	  
	  
	  public static BookingResp generateBookingId(String url,String bookingData) throws IOException {

	          
	       
	            HttpPost httpReq = new HttpPost(url);
	           
		        String auth=ProductUtil.zenotiAccessKey;
	          
				String authHeader = "apikey " + auth;
				httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
                StringEntity entity = new StringEntity(bookingData);
				httpReq.setEntity(entity);
				httpReq.setHeader("Accept", "*/*");
				httpReq.setHeader("Content-type", "application/json");
	            httpReq.setEntity(entity);
	            CloseableHttpClient httpClient = HttpClients.createDefault();
	            CloseableHttpResponse response = httpClient.execute(httpReq);

	           String result = EntityUtils.toString(response.getEntity());
	           
	            BookingResp  bookingResp =  new Gson().fromJson(result, BookingResp.class);

	        return bookingResp;
	    }

	  
	  
	  public static Object getTimeSlots(String url,String bookingId) throws IOException {

		   
		    url=url+"/"+bookingId+"/slots?check_future_day_availability=true";
		    
	        HttpGet httpReq = new HttpGet(url);
	      
	     
	       String auth=ProductUtil.zenotiAccessKey;
			String authHeader = "apikey " + auth;
			
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	               
	        CloseableHttpResponse response = httpClient. execute(httpReq);
	        
            String result = EntityUtils.toString(response.getEntity());
	            
            
            if(response.getStatusLine().getStatusCode()==200)
	         {
            	 SlotsResp  slotsResp =  new Gson().fromJson(result, SlotsResp.class);
	        	 return slotsResp;
	         }
	         else
	         {
	        	 ApiError  apiError =  new Gson().fromJson(result, ApiError.class); 
	        	 apiError.setStatusCode(response.getStatusLine().getStatusCode());
	        	 return apiError;
	         }
           
	    }
	  
	  
	  
	  public static Object getReserveTimeSlot(String url,String bookingId,String timeSlot) throws IOException {

		   
		    url=url+"/"+bookingId+"/slots/reserve";
		      
            HttpPost httpReq = new HttpPost(url);
          
	        String auth=ProductUtil.zenotiAccessKey;
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
            StringEntity entity = new StringEntity(timeSlot);
			httpReq.setEntity(entity);
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
            httpReq.setEntity(entity);
            CloseableHttpClient httpClient = HttpClients.createDefault();
            CloseableHttpResponse response = httpClient.execute(httpReq);

           String result = EntityUtils.toString(response.getEntity());
           
            if(response.getStatusLine().getStatusCode()==200)
            
            {
            	  SlotReserveResp  slotReserveResp =  new Gson().fromJson(result, SlotReserveResp.class);
	        	 return slotReserveResp;
	         }
	         else
	         {
	        	 BookingError  bookingError =  new Gson().fromJson(result, BookingError.class); 
	        	
	        	 return bookingError;
	         }
	         
	       
	    }
	  
	  
	  public static Object therapistAvailablity(String url,String bookingData) throws IOException {

         
    
         HttpPost httpReq = new HttpPost(url);
      
	       String auth=ProductUtil.zenotiAccessKey;
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
            StringEntity entity = new StringEntity(bookingData);
			httpReq.setEntity(entity);
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
         httpReq.setEntity(entity);
         CloseableHttpClient httpClient = HttpClients.createDefault();
         CloseableHttpResponse response = httpClient.execute(httpReq);

        String result = EntityUtils.toString(response.getEntity());
         if(response.getStatusLine().getStatusCode()==200)
         {
        	 
        	 TherapistAvailableResp  therapistAvailableResp =  new Gson().fromJson(result, TherapistAvailableResp.class);
        	 return therapistAvailableResp;
         }
         else
         {
        	 TherapistError  therapistError =  new Gson().fromJson(result, TherapistError.class);
        	 return therapistError;
         }
        
        

    
 }
	  
	  
	  public static Object confirSlot(String url,String bookingId) throws IOException {

		   
		    url=url+"/"+bookingId+"/slots/confirm";
		    
		    
		      
          HttpPost httpReq = new HttpPost(url);
        
	       String auth=ProductUtil.zenotiAccessKey;
	     
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
        
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
        
          CloseableHttpClient httpClient = HttpClients.createDefault();
          CloseableHttpResponse response = httpClient.execute(httpReq);

          String result = EntityUtils.toString(response.getEntity());
        
         
          if(response.getStatusLine().getStatusCode()==200)
          
          {
        	  ServiceConfirmResp  slotReserveResp =  new Gson().fromJson(result, ServiceConfirmResp.class);
        	  
        	  
	        	 return slotReserveResp;
	         }
	         else
	         {
	        	 ApiError  apiError =  new Gson().fromJson(result, ApiError.class); 
	        	 apiError.setStatusCode(response.getStatusLine().getStatusCode());
	        	
	        	 return apiError;
	         }
	         
	       
	    }
	  

	  public static Object getAppointmentDetails(String url,String guestId) throws IOException {

		   
		  url=url+"/"+guestId+"/appointments";
		    
	        HttpGet httpReq = new HttpGet(url);
	       
	        Object	barberResp  = ProductService.getTherapists(ProductUtil.zenotiCenters);
	        String bookingData = new Gson().toJson(barberResp);
	        TherapistResp  therapistResp =  new Gson().fromJson(bookingData, TherapistResp.class);
	        Map<String,String> hmap=new HashMap<>();
	       
	        Arrays.stream(therapistResp.getTherapists()).forEach((e)->{
	     
	        	hmap.put(e.getId(), e.getPersonal_info().getName());
	        });
	        
	       
	      String auth=ProductUtil.zenotiAccessKey;
	       
			String authHeader = "apikey " + auth;
			
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	               
	        CloseableHttpResponse response = httpClient. execute(httpReq);
	        
          String result = EntityUtils.toString(response.getEntity());
	           
          
          if(response.getStatusLine().getStatusCode()==200)
	         {
        	  AppointmentsResp  appointmentsResp =  new Gson().fromJson(result, AppointmentsResp.class);
        	  
        	  Appointments[] appointments=appointmentsResp.getAppointments();
        	  
        	   Arrays.stream(appointments).forEach((e)->{
        		  
        		  AppointmentServices[] appointment_services=e.getAppointment_services();
        		  
        		  Arrays.stream(appointment_services).forEach((d)->{
        			  
        			d.setTherapist_name(hmap.get(d.getRequested_therapist_id()));
        		  });
        		  
        		   appointmentsResp.setAppointments(appointments);;
        		 
        	  });
        	  
        	   return appointmentsResp;
	         }
	         else
	         {
	        	 ApiError  apiError =  new Gson().fromJson(result, ApiError.class); 
	        	 apiError.setStatusCode(response.getStatusLine().getStatusCode());
	        	 return apiError;
	         }
         
	    }
	  
	  
	  public static Object cancelAppointmet(String url,String bookingData,String invoiceId) throws IOException {

		   
		    url=url+"/"+invoiceId+"/cancel";
		        
            HttpPut httpReq = new HttpPut(url);
    
	      String auth=ProductUtil.zenotiAccessKey;
	      
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
		  StringEntity entity = new StringEntity(bookingData);
			httpReq.setEntity(entity);
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
			 httpReq.setEntity(entity);
      CloseableHttpClient httpClient = HttpClients.createDefault();
      CloseableHttpResponse response = httpClient.execute(httpReq);

      String  result = EntityUtils.toString(response.getEntity());
    
     
      if(response.getStatusLine().getStatusCode()==200)
      
      {
      	CancelServiceResp  cancelServiceResp =  new Gson().fromJson(result, CancelServiceResp.class);
    	  
      	return cancelServiceResp;
	         }
	         else
	         {
	        	 ApiError  apiError =  new Gson().fromJson(result, ApiError.class); 
	        	 apiError.setStatusCode(response.getStatusLine().getStatusCode());
	        	
	        	 return apiError;
	         }
	         
	       
	    }
	  
	  
	  public static GuestDetails createGuest(String url,String bookingData) throws IOException {

	       
	  
	        HttpPost httpReq = new HttpPost(url);
	        String auth=ProductUtil.zenotiAccessKey;
	        String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
	        StringEntity entity = new StringEntity(bookingData);
			httpReq.setEntity(entity);
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
	       httpReq.setEntity(entity);
	       CloseableHttpClient httpClient = HttpClients.createDefault();
	       CloseableHttpResponse response = httpClient.execute(httpReq);

	     String result = EntityUtils.toString(response.getEntity());
	    
	     GuestDetails  guestResp =  new Gson().fromJson(result, GuestDetails.class);

	   return guestResp;
	}
	  
	
	  
	  public static TherapistServiceResp getTherapistsByServiceId(String url,String serviceId) throws IOException {

		    url=url+"?centerId="+ProductUtil.centerId+"&Size=50&ServiceId="+serviceId+"&ignoreAddonPricing=true&UserMembershipId";
		    
		    HttpGet httpReq = new HttpGet(url);
	      
	         String auth=ProductUtil.zenotiAccessKey;
		
		   
			String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	       
			CloseableHttpResponse response = httpClient. execute(httpReq);
         
			String result = EntityUtils.toString(response.getEntity());
			
		     
			TherapistServiceResp therapistResp = new Gson().fromJson(result, TherapistServiceResp.class);
			
		 
	        return therapistResp;
	    }
	  
	  
	  
	  public static GuestUpdateResp getGuestDetails(String url,String email) throws IOException {

		   
		    url=url+"?center_id="+ProductUtil.centerId+"&email="+email;
		    
	        HttpGet httpReq = new HttpGet(url);
	      
	       String auth=ProductUtil.zenotiAccessKey;
			String authHeader = "apikey " + auth;
			
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
			
			CloseableHttpClient httpClient = HttpClientBuilder.create().build();
	               
	        CloseableHttpResponse response = httpClient. execute(httpReq);
	        
	        String result = EntityUtils.toString(response.getEntity());
	            
	        GuestUpdateResp  guestDetails =  new Gson().fromJson(result, GuestUpdateResp.class);
	         
	        return guestDetails;
	    }
	 
	  
	  
	  public static Rescresp confirmAppointmentMail(String url,String bookingData) throws IOException {

		 
		    
		  HttpPost httpReq = new HttpPost(url);
	        String auth=ProductUtil.rescKey;
	        String authHeader = "ApiKey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
	        StringEntity entity = new StringEntity(bookingData);
			httpReq.setEntity(entity);
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
	       httpReq.setEntity(entity);
	       CloseableHttpClient httpClient = HttpClients.createDefault();
	       CloseableHttpResponse response = httpClient.execute(httpReq);

	     String result = EntityUtils.toString(response.getEntity());
	    
	     Rescresp  rescresp =  new Gson().fromJson(result, Rescresp.class);
		 
	        return rescresp;
	    }
	  
	  
	  public static GuestUpdate updateGuest(String url,String bookingData,String guestId) throws IOException {

		    url=url+"/"+guestId+"?expand=tags&expand=address_info&expand=preferences&expand=referral&expand=primary_employee";
		    HttpPut httpReq = new HttpPut(url);
            String auth=ProductUtil.zenotiAccessKey;
	        String authHeader = "apikey " + auth;
			httpReq.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
		    StringEntity entity = new StringEntity(bookingData);
			httpReq.setEntity(entity);
			httpReq.setHeader("Accept", "*/*");
			httpReq.setHeader("Content-type", "application/json");
			httpReq.setEntity(entity);
	        CloseableHttpClient httpClient = HttpClients.createDefault();
	        CloseableHttpResponse response = httpClient.execute(httpReq);
	        String result = EntityUtils.toString(response.getEntity());
	       
	        GuestUpdate  res =  new Gson().fromJson(result, GuestUpdate.class);
	 
	     return res;
	    }
	  
	  
	  public static String ResetEmail(String url,ResetEmail resetEmail,String accessToken) throws IOException {

	        
	       HttpPost post = new HttpPost(url);
	       List<NameValuePair> urlParameters = new ArrayList<>();
	       urlParameters.add(new BasicNameValuePair("client_id", ProductUtil.clientId));
	       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
	       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
	       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
	       urlParameters.add(new BasicNameValuePair("form", "editProfileForm"));
	      urlParameters.add(new BasicNameValuePair("emailAddress", resetEmail.getUpdatedEmail()));
	      urlParameters.add(new BasicNameValuePair("access_token", accessToken));
	      post.setEntity(new UrlEncodedFormEntity(urlParameters));
	      CloseableHttpClient httpClient = HttpClients.createDefault();
	      CloseableHttpResponse response = httpClient.execute(post);
	      String result = EntityUtils.toString(response.getEntity());
	         
	       return result;
	    }
	 
}
