package com.oldspice.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpHeaders;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import com.oldspice.model.EditProfile;
import com.oldspice.model.ForgetPassword;
import com.oldspice.model.JanRainUser;
import com.oldspice.model.JanrainLogin;
import com.oldspice.model.ResetPassword;
import com.oldspice.model.SendRestCodeToMail;
import com.oldspice.util.ProductUtil;

public class LoginService {

    
    public static String sendPasswordResetCodeToMail(String url,SendRestCodeToMail sendRestCodeToMail) throws IOException {

       
       HttpPost post = new HttpPost(url);
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("client_id",ProductUtil.clientId));
       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
       urlParameters.add(new BasicNameValuePair("redirect_uri",  "http://localhost"));
       urlParameters.add(new BasicNameValuePair("form", "forgotPasswordForm"));
       urlParameters.add(new BasicNameValuePair("signInEmailAddress", sendRestCodeToMail.getSignInEmailAddress()));
    
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        CloseableHttpClient httpClient = HttpClients.createDefault();
        CloseableHttpResponse response = httpClient.execute(post);
        String result = EntityUtils.toString(response.getEntity());
         

        return result;
    }
    
    
    public static String getoauthToken(String url,String code) throws IOException {

       
        HttpPost post = new HttpPost(url);
        
        String auth = ProductUtil.clientId + ":" + ProductUtil.clientSecret;
        byte[] encodedAuth = Base64.encodeBase64(
		auth.getBytes(StandardCharsets.ISO_8859_1));
		String authHeader = "Basic " + new String(encodedAuth);
		post.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
       
	   List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("grant_type", "authorization_code"));
       urlParameters.add(new BasicNameValuePair("code", code));
       urlParameters.add(new BasicNameValuePair("redirect_uri", ProductUtil.loginOauthRedirectUrl));
       post.setEntity(new UrlEncodedFormEntity(urlParameters));
       CloseableHttpClient httpClient = HttpClientBuilder.create().build();
       CloseableHttpResponse response = httpClient. execute(post);
       String result = EntityUtils.toString(response.getEntity());
        

        return result;
    }
    
    
    
    
    public static String resetPasswordForEditProfile(String url,ResetPassword resetPassword) throws IOException {

       
        HttpPost post = new HttpPost(url);
        
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("client_id", ProductUtil.clientId));
       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
       urlParameters.add(new BasicNameValuePair("form","changePasswordForm"));
       urlParameters.add(new BasicNameValuePair("currentPassword", resetPassword.getCurrentPassword()));
       urlParameters.add(new BasicNameValuePair("newPassword", resetPassword.getNewPassword()));
       urlParameters.add(new BasicNameValuePair("newPasswordConfirm", resetPassword.getNewPasswordConfirm()));
       urlParameters.add(new BasicNameValuePair("access_token", resetPassword.getCode()));
       post.setEntity(new UrlEncodedFormEntity(urlParameters));
       CloseableHttpClient httpClient = HttpClients.createDefault();
       CloseableHttpResponse response = httpClient.execute(post);
       String result = EntityUtils.toString(response.getEntity());
         

        return result;
    }
    
    
    public static String resetPassword(String url,ForgetPassword resetPassword) throws IOException {

        String result = "";
        HttpPost post = new HttpPost(url);
        
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("client_id", ProductUtil.clientId));
       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
       urlParameters.add(new BasicNameValuePair("redirect_uri","http://localhost"));
       urlParameters.add(new BasicNameValuePair("form", "changePasswordFormNoAuth"));
       urlParameters.add(new BasicNameValuePair("newPassword", resetPassword.getNewPassword()));
       urlParameters.add(new BasicNameValuePair("newPasswordConfirm", resetPassword.getNewPasswordConfirm()));
       urlParameters.add(new BasicNameValuePair("access_token", resetPassword.getCode()));
       post.setEntity(new UrlEncodedFormEntity(urlParameters));
     

        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             CloseableHttpResponse response = httpClient.execute(post)){

            result = EntityUtils.toString(response.getEntity());
         }

        return result;
    }
    
    
    
    public static String signIn(String url,JanrainLogin login) throws IOException {

       
       HttpPost post = new HttpPost(url);
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("client_id", ProductUtil.clientId));
       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
       urlParameters.add(new BasicNameValuePair("redirect_uri",  "http://localhost"));
       urlParameters.add(new BasicNameValuePair("response_type", "token"));
       urlParameters.add(new BasicNameValuePair("form", "signInForm"));
       urlParameters.add(new BasicNameValuePair("signInEmailAddress", login.getSignInEmailAddress()));
       urlParameters.add(new BasicNameValuePair("currentPassword", login.getCurrentPassword()));
       post.setEntity(new UrlEncodedFormEntity(urlParameters));
       CloseableHttpClient httpClient = HttpClients.createDefault();
       CloseableHttpResponse response = httpClient.execute(post);
        String result = EntityUtils.toString(response.getEntity());
        
        return result;
    }
    
    
    public static String userRegister(String url,JanRainUser user) throws IOException {

       
       HttpPost post = new HttpPost(url);
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("client_id", ProductUtil.clientId));
       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
       urlParameters.add(new BasicNameValuePair("redirect_uri",  "http://localhost"));
       urlParameters.add(new BasicNameValuePair("form", "registrationForm"));
       urlParameters.add(new BasicNameValuePair("language", "en-US"));
       urlParameters.add(new BasicNameValuePair("globalOpt_optVersion", "1"));
       urlParameters.add(new BasicNameValuePair("globalOpt_optId", "178_01"));
       urlParameters.add(new BasicNameValuePair("globalOpt_optStatus", "true"));
       urlParameters.add(new BasicNameValuePair("firstName", user.getFirstName()));
       urlParameters.add(new BasicNameValuePair("lastName", user.getLastName()));
       urlParameters.add(new BasicNameValuePair("emailAddress", user.getEmailAddress()));
       urlParameters.add(new BasicNameValuePair("newPassword", user.getPassword()));
       urlParameters.add(new BasicNameValuePair("newPasswordConfirm", user.getConfirmPassword()));
       post.setEntity(new UrlEncodedFormEntity(urlParameters));
       CloseableHttpClient httpClient = HttpClients.createDefault();
       CloseableHttpResponse response = httpClient.execute(post);
       String result = EntityUtils.toString(response.getEntity());
         
      return result;
    }
    
    public static String editProfile(String url,EditProfile editProfile) throws IOException {

        
       HttpPost post = new HttpPost(url);
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("client_id", ProductUtil.clientId));
       urlParameters.add(new BasicNameValuePair("flow", "oldspice_us"));
       urlParameters.add(new BasicNameValuePair("flow_version", ProductUtil.loginFlowVersion));
       urlParameters.add(new BasicNameValuePair("locale", "en-US"));
       urlParameters.add(new BasicNameValuePair("form", "editProfileForm"));
       urlParameters.add(new BasicNameValuePair("firstName", editProfile.getFirstName()));
       urlParameters.add(new BasicNameValuePair("lastName", editProfile.getLastName()));
       urlParameters.add(new BasicNameValuePair("access_token", editProfile.getAccessToken()));
      post.setEntity(new UrlEncodedFormEntity(urlParameters));
      CloseableHttpClient httpClient = HttpClients.createDefault();
      CloseableHttpResponse response = httpClient.execute(post);
      String result = EntityUtils.toString(response.getEntity());
         
    return result;
    }
   
}
